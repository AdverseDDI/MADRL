from matplotlib import pyplot  
import scipy as sp  
import numpy as np  
import pandas as pd
from matplotlib import pylab  
from sklearn.datasets import load_files   
from sklearn.feature_extraction.text import  CountVectorizer  
from sklearn.feature_extraction.text import  TfidfVectorizer  
from sklearn.naive_bayes import MultinomialNB  
from sklearn.metrics import classification_report  
from sklearn.linear_model import LogisticRegression  
import time 
from scipy.linalg.misc import norm
from numpy import *
import copy
from sklearn import metrics
import torch
from torch.autograd import Variable
from torch import nn, optim
from torch.utils.data import DataLoader
from torchvision.utils import save_image
from sklearn.metrics import confusion_matrix
from EvaluationMetricsAUCAUPRComputation import roc_auc_score,average_precision_score
np.set_printoptions(threshold=np.inf) 
torch.set_printoptions(threshold=np.inf) 
from SharedAttributeRepresentationLearning import SharedAttributeRepresentationLearningGenerators
from SharedAttributeRepresentationLearning import SharedAttributeRepresentationLearningDiscriminator
from SharedAttributeRepresentationLearning import GeneratorConsensusScore
# import Generators and Discriminator as well as GeneratorConsensusScore from 
# SharedAttributeRepresentationLearning
from SpecificAttributeRepresentationLearning import SpecificAttributeRepresentationLearningGenerators
from SpecificAttributeRepresentationLearning import SpecificAttributeRepresentationLearningDiscriminator
from SpecificAttributeRepresentationLearning import GeneratorComplementaryScore
# import Generators and Discriminator as well as GeneratorComplementaryScore from 
# SpecificAttributeRepresentationLearning
from MultiAttributeLearningForADDIPrediction import DeepNeuralNetworkForADDIModeling
from MultiAttributeLearningForADDIPrediction import LossFunctionOfPredictedAndGroundTruthAdverseInteractionVector
# import the deep network network DeepNeuralNetworkForADDIModeling for modeling the relation between 
# thefinal attribute representations and Adverse interaction vectors
# import LossFunctionOfPredictedAndGroundTruthAdverseInteractionVector to calculate loss function between 
# the predicted Adverse interaction vector and the ground-truth Adverse interaction vector of an Adverse drug pair
np.random.seed(1)
torch.manual_seed(1)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
# test whether cuda is available or not

# This class is used to record the adverse interactions among adverse drug pair, 
# in which DrugID1 and DrugID2 are the drug indexes in the adverse drug pair, and 
# AdverseInteractionVector is the ground-truth adverse interaction vector caused by 
# (DrugID1,DrugID2) adverse drug pair. The length of AdverseInteractionVector is equal to
# AdverseInteractionLength in MultiAttributeLearningForADDIPrediction.py
class AdverseInteraction:
    def __init__(self,DrugID1,DrugID2,AdverseInteractionVector):
    	# i.e., (d_i, d_j, r_{ij}^K) in the paper, d_i=DrugID, d_j=DrugID2, 
    	# r_{ij}^K=AdverseInteractionVector
        self.DrugID1 = DrugID1 
        self.DrugID2 = DrugID2
        self.AdverseInteractionVector=AdverseInteractionVector

# This function is to load the data of the adverse interactions among drugs from 
# AdverseInteractionDatasetbyDrugPairAdverseVector.txt. To be specific, there are totally 
# 1,188,258 adverse interactions associated with 567 drugs and 12481 adverse drug pair.
# In AdverseInteractionDatasetbyDrugPairAdverseVector.txt, each line records three entries,
# the first two entries is the drug ID of d_i and d_j, the last entry is the adverse interaction 
# vector r_{ij}^K induced by (d_i, d_j), in which if (d_i, d_j) leads to the k-th adverse interactions, 
# the k-th element in vector r_{ij}^K is 1, otherwise 0. The number of adverse interaction,
# i.e., the length of vector r_{ij}^K is denoted as AdverseInteractionLength. In the experiments, 
# AdverseInteractionLength (i.e., K) is set to be 258
def LoadAdverseInteractionData(AdverseInteractionDataAddress):
# input: AdverseInteractionDataAddress is the address of the adverse interaction data
# AdverseInteractionDataAddress='AdverseInteractionDatasetbyDrugPairAdverseVector.txt'
	AdverseInteractionDataset=[]
	# AdverseInteractiondataset records the all adverse interaction data in the form of 
	# class AdverseInteraction defined above
	fileIn=open(AdverseInteractionDataAddress)
	# open the file AdverseInteractionDatasetbyDrugPairAdverseVector.txt
	line=fileIn.readline()
	# read the first line
	while line:
		lineArr=line.strip().split('\t')
		# Split each line by Tab i.e., \t
		DrugID1=(int)(lineArr[0].strip())
		DrugID2=(int)(lineArr[1].strip())
		# get the first two entries of each line, i.e., the DrugID of the adverse drug pair
		lineSpace=lineArr[2].strip().split() 
		# the last entry is the binary vector splitted by space ' ' being the adverse interaction 
		# vector of (DrugID1,DrugID2). The k-th element represents that whether the k-th adverse 
		# interaction can be caused by (DrugID1,DrugID2). If the k-th adverseinteraction can be caused 
		# by (DrugID1,DrugID2), then the corresponding element is 1, otherwise 0
		AdverseInteractionVector=[]
		# Initialize list AdverseInteractionVector to record the Adverse interaction induced by (DrugID1,DrugID2)
		for i in lineSpace:
			AdverseInteractionVector.append(float(i))
		# append each element into AdverseInteractionVector
		AdverseInteractionVector=np.array(AdverseInteractionVector)
		# convert list AdverseInteractionVector into array
		AdverseInteractionVector=torch.Tensor(AdverseInteractionVector)
		# convert AdverseInteractionVector into Tensor for the convenience of model training in GPU
		ADDISample=AdverseInteraction(DrugID1,DrugID2,AdverseInteractionVector)
		# Initialize an object ADDISample of the class AdverseInteraction 
		# by (DrugID1,DrugID2,AdverseInteractionVector)
		AdverseInteractionDataset.append(ADDISample)
		# append the Initialized object into AdverseInteractionDataset
		line=fileIn.readline()
		# read the next line (i.e., the Adverse interaction of the next adverse drug pair)
	return AdverseInteractionDataset

# This function is to load the ReconstructedAttributeMatrices of eight attributes, i.e., 
# 1. ReconstructedMolecularStructureMatrix.npy, 2. ReconstructedTargetMatrix.npy,
# 3. ReconstructedEnzymeMatrix.npy, 4. ReconstructedPathwayMatrix.npy, 5. ReconstructedSideEffectMatrix.npy
# 6. ReconstructedPhenotypeMatrix.npy, 7. ReconstructedGeneMatrix.npy, 8. ReconstructedDiseaseMatrix.npy
# this eight matrices are derived by using the representative drugs with their discriminative features
# to reconstructed their original feature spaces. That means each attribute representation of drugs is 
# representated by the representative drugs and discriminative features. Noticeably, the above 
# eight ReconstructedAttributeMatrix files is NPY files that cannot be read directly. 
# The detailed reconstruction process and detailed ReconstructedAttributeMatrix information are provided
#  in the file address 1. Joint Representative Drug and Discriminative Feature Selection\1. Molecular Structure,
# 2. Target, 3. Enzyme, 4. Pathway, 5. Side Effect,  6. Phenotype, 7. Gene, 8. Disease. 
def LoadReconstructionAttributeMatrixInNPYform(ReconstructionAttributeMatrixAddress):
	ReconstructionAttributeMatrix=np.load(ReconstructionAttributeMatrixAddress)
	# use ReconstructionAttributeMatrixAddress to get the ReconstructionAttributeMatrix
	ReconstructionAttributeMatrix=np.mat(ReconstructionAttributeMatrix)
	# convert array ReconstructionAttributeMatrix into matrix 
	ReconstructionAttributeMatrix=torch.Tensor(ReconstructionAttributeMatrix)
	# convet matrix into Tensor for the convenience of model training in GPU
	if torch.cuda.is_available():
		ReconstructionAttributeMatrix.cuda()
	# load ReconstructionAttributeMatrix into GPU	
	return ReconstructionAttributeMatrix

# This function is to randomly select Percentage of adverse interactions among drugs from 
# AdverseInteractionDataset for training, then use the remaining adverse interactions among drugs
# for testing. Given the AdverseInteractionDataset output by function LoadAdverseInteractionData
# and the Percentage for training, the number of adverse interactions for training is 
# Len(LoadAdverseInteractionData)*Percentage, the number of adverse interactions for testing is 
# Len(LoadAdverseInteractionData)*(1-Percentage)
def RandomTrainingSampleAndTestingSampleSeletion(AdverseInteractionDataset, Percentage):
# input AdverseInteractionDataset is the total adverse interaction set
# Percentage is the percentage for training
	AdverseInteractionNum=len(AdverseInteractionDataset)
	# get the number of adverse interactions in AdverseInteractionDataset
	AdverseInteractionTrainingNum=(int)(AdverseInteractionNum*Percentage)
	# get the number of adverse interactions for training
	AdverseInteractionDatasetTemp=copy.deepcopy(AdverseInteractionDataset)
	# get a deep copy from AdverseInteractionDataset 
	# AdverseInteractionDataset and AdverseInteractionDatasetTemp are two individual list 
	AdverseInteractionTrainingList=[]
	# Initialize a list to store the selected adverse interactions for training
	AdverseInteractionTestingList=[]
	# Initialize a list to store the selected adverse interactions for testing
	AdverseInteractionNumTemp=AdverseInteractionNum
	# get a copy from AdverseInteractionNum to record the 
	# number of adverse interactions in the remaining dataset 
	for i in range (AdverseInteractionTrainingNum):
	# traverse from 0 to AdverseInteractionTrainingNum-1 for generating the random index 
	# from AdverseInteractionTrainingNumTemp
		RandomInt=random.randint(0,AdverseInteractionNumTemp)
		# get a random number from 0 to AdverseInteractionNumTemp-1
		AdverseInteractionTrainingList.append(AdverseInteractionDatasetTemp[RandomInt])
		# random select a sample with index=RandomInt from AdverseInteractionDatasetTemp
		# as a training sample
		del AdverseInteractionDatasetTemp[RandomInt]
		# delete AdverseInteractionDatasetTemp[RandomInt] from AdverseInteractionDatasetTemp
		AdverseInteractionNumTemp=AdverseInteractionNumTemp-1
		# the number of adverse interactions the remaining dataset 
		# AdverseInteractionNumTemp-1
	AdverseInteractionTestingList=AdverseInteractionDatasetTemp
	# after selecting AdverseInteractionTrainingNum samples from AdverseInteractionDatasetTemp
	# and deleting the selected samples from AdverseInteractionDatasetTemp, the remaining samples 
	# in AdverseInteractionDatasetTemp can be used for testing
	return AdverseInteractionTrainingList,AdverseInteractionTestingList
	# return the training and testing samples


# Training Module to capture the generators and discriminator for shared attribute 
# representation learning, in which generators G_{a}^m and G_{a}^n aim at maximizing 
# consensus score P^{mn}_{ij} for capturing the consistent properties between the m-th 
# and the n-th attributes and exploiting their accordant contributions in ADDI modeling, 
# while discriminator D_{a}^{mn} seeks to minimize P^{mn}_{ij}. the designed generators 
# and discriminator are specifically associated with opposite optimization objectives, 
# implying that the generated shared attribute representations G_{a}^m(H^m_{ij}) and 
# G_{a}^n(H^n_{ij}) tries to deceive discriminator D_{a}^{mn} such that the derived 
# G_{a}^m(H^m_{ij}) and G_{a}^n(H^n_{ij}) in the final state can be as consistent as 
# possible and contribute to presenting consensus effects in ADDI prediction. 
def TrainingModuleForSharedAttributeRepresentationLearningWithGeneratorAndDiscriminator(
	AdverseInteractionTrainingList,ReconstructionMolecularStructureMatrix,ReconstructedTargetMatrix,
	ReconstructedEnzymeMatrix,ReconstructedPathwayMatrix,ReconstructedSideEffectMatrix,
	ReconstructedPhenotypeMatrix,ReconstructedGeneMatrix,ReconstructedDiseaseMatrix):
# input: AdverseInteractionTrainingList is the adverse interactions among drugs for training
# ReconstructionMolecularStructureMatrix,ReconstructedTargetMatrix,	ReconstructedEnzymeMatrix,
# ReconstructedPathwayMatrix,ReconstructedSideEffectMatrix,ReconstructedPhenotypeMatrix,
# ReconstructedGeneMatrix,and ReconstructedDiseaseMatrix are reconstructed Molecular 
# Structure, Target, Enzyme, Pathway, Side Effect, Phenotype, Gene, and Disease matrices of drugs
	MolecularStructureDimension=np.shape(ReconstructionMolecularStructureMatrix)[1]
	# return the dimensionality of MolecularStructure, i.e., 881 in the paper
	TargetDimension=np.shape(ReconstructedTargetMatrix)[1]
	# return the dimensionality of Target, i.e., 1065 in the paper
	EnzymeDimension=np.shape(ReconstructedEnzymeMatrix)[1]
	# return the dimensionality of Enzyme, i.e., 497 in the paper
	PathwayDimension=np.shape(ReconstructedPathwayMatrix)[1]
	# return the dimensionality of Pathway, i.e., 396 in the paper
	SideEffectDimension=np.shape(ReconstructedSideEffectMatrix)[1]
	# return the dimensionality of SideEffect, i.e., 3687 in the paper
	PhenotypeDimension=np.shape(ReconstructedPhenotypeMatrix)[1]
	# return the dimensionality of Phenotype, i.e., 2193 in the paper
	GeneDimension=np.shape(ReconstructedGeneMatrix)[1]
	# return the dimensionality of Gene, i.e., 4683 in the paper
	DiseaseDimension=np.shape(ReconstructedDiseaseMatrix)[1]
	# return the dimensionality of Disease, i.e., 482 in the paper

	LearningRate_Generator = 0.0001
	LearningRate_Discriminator = 0.0001
	# set the initial learning rate for Generator and Discriminator as 10^{-4}
	Weight_Decay=0.000001
	# set the weight decay for Generator and Discriminator as 10^{-6}
	
	SharedAttributeRepresentationLearningGen=SharedAttributeRepresentationLearningGenerators(
		2*MolecularStructureDimension,2*TargetDimension,2*EnzymeDimension,2*PathwayDimension,
		2*SideEffectDimension,2*PhenotypeDimension,2*GeneDimension,2*DiseaseDimension).to(device)
	# Initialize SharedAttributeRepresentationLearningGenerators for generating the shared attribute 
	# representations of each adverse drug pair in terms of each attribute. 
	# This generator is defined in SharedAttributeRepresentationLearning.py
	# due to that concatenation operation is used to fuse the attribute representation 
	# of two drugs into the attribute representation of drug pairs, the input dimension  
	# for the generators in terms of eight attribute are 2*dimension(attribute)
	# .to(device) is to load the neural network into cuda
	SharedAttributeRepresentationLearningDis=SharedAttributeRepresentationLearningDiscriminator().to(device)
	# Initialize SharedAttributeRepresentationLearningDiscriminator for discriminating the generated
	# the shared attribute representations of each pair of attributes for minimizing the consensus score 
	# to exploit their consistent contributions in ADDI modeling

	Option_Generator=torch.optim.Adam(SharedAttributeRepresentationLearningGen.parameters(),
		lr=LearningRate_Generator,weight_decay=Weight_Decay)
	# set the learning rate, weight_decay of the generators
	Option_Discriminator=torch.optim.Adam(SharedAttributeRepresentationLearningDis.parameters(),
		lr=LearningRate_Discriminator,weight_decay=Weight_Decay)
	# set the learning rate, weight_decay of the Discriminator
	print('Training Generator and Discriminator for Shared Attribute Representation Learning!!!')
	MaxIter=50
	# set the number of iterations to be 50
	for Iter in range(MaxIter):
		# for each iteration
		for ADDISample in AdverseInteractionTrainingList:
		# traverse each sample in the training set AdverseInteractionTrainingList
			DrugID1=ADDISample.DrugID1
			DrugID2=ADDISample.DrugID2
			# get two drug indexes of the adverse drug pair
			print('%d Iterations For Shared Attribute Representation Learning: Train Adverse Drug Pair (%d, %d)' %(Iter,DrugID1,DrugID2))	
			AdverseInteractionVector=ADDISample.AdverseInteractionVector
			# get the adverse interaction vector of adverse drug pair (DrugID1,DrugID2)
			MolecularStructureVectorPair=torch.cat((ReconstructionMolecularStructureMatrix[DrugID1],
				ReconstructionMolecularStructureMatrix[DrugID2]),0)
			# ReconstructionMolecularStructureMatrix[DrugID1] is the reconstructed Molecular Structure 
			# vector of DrugID1, ReconstructionMolecularStructureMatrix[DrugID2] is the reconstructed
			# Molecular Structure vector of DrugID2. Based on concatenation operation, we obtain the  
			# reconstructed Molecular Structure representation of adverse drug pair (DrugID1, DrugID2)
			# as MolecularStructureVectorPair. torch.cat( ,0) is the concatenation operation in the first dimension. 
			TargetVectorPair=torch.cat((ReconstructedTargetMatrix[DrugID1],ReconstructedTargetMatrix[DrugID2]),0)
			# ReconstructedTargetMatrix[DrugID1] is the reconstructed Target vector of DrugID1, 
			# ReconstructionMolecularStructureMatrix[DrugID2] is the reconstructed Target vector of DrugID2, 
			# Based on concatenation operation, we obtain the  reconstructed Target representation 
			# of adverse drug pair (DrugID1, DrugID2) as TargetVectorPair.
			EnzymeVectorPair=torch.cat((ReconstructedEnzymeMatrix[DrugID1],ReconstructedEnzymeMatrix[DrugID2]),0)
			# concatenate the reconstructed Enzyme vector of DrugID1 and DrugID2 into the reconstructed 
			# Enzyme representations of adverse drug pair (DrugID1, DrugID2)
			PathwayVectorPair=torch.cat((ReconstructedPathwayMatrix[DrugID1],ReconstructedPathwayMatrix[DrugID2]),0)
			# concatenate the reconstructed Pathway vector of DrugID1 and DrugID2 into the reconstructed 
			# Pathway representations of adverse drug pair (DrugID1, DrugID2)
			SideEffectVectorPair=torch.cat((ReconstructedSideEffectMatrix[DrugID1],ReconstructedSideEffectMatrix[DrugID2]),0)
			# concatenate the reconstructed SideEffect vector of DrugID1 and DrugID2 into the reconstructed 
			# SideEffect representations of adverse drug pair (DrugID1, DrugID2)
			PhenotypeVectorPair=torch.cat((ReconstructedPhenotypeMatrix[DrugID1],ReconstructedPhenotypeMatrix[DrugID2]),0)
			# concatenate the reconstructed Phenotype vector of DrugID1 and DrugID2 into the reconstructed 
			# Phenotype representations of adverse drug pair (DrugID1, DrugID2)
			GeneVectorPair=torch.cat((ReconstructedGeneMatrix[DrugID1],ReconstructedGeneMatrix[DrugID2]),0)
			# concatenate the reconstructed Gene vector of DrugID1 and DrugID2 into the reconstructed 
			# Gene representations of adverse drug pair (DrugID1, DrugID2)
			DiseaseVectorPair=torch.cat((ReconstructedDiseaseMatrix[DrugID1],ReconstructedDiseaseMatrix[DrugID2]),0)
			# concatenate the reconstructed Disease vector of DrugID1 and DrugID2 into the reconstructed 
			# Disease representations of adverse drug pair (DrugID1, DrugID2)	

			SharedMolecularStructureVectorPair,SharedTargetVectorPair,SharedEnzymeVectorPair,\
			SharedPathwayVectorPair,SharedSideEffectVectorPair,SharedPhenotypeVectorPair,SharedGeneVectorPair,\
			SharedDiseaseVectorPair=SharedAttributeRepresentationLearningGen(MolecularStructureVectorPair,
				TargetVectorPair,EnzymeVectorPair,PathwayVectorPair,SideEffectVectorPair,PhenotypeVectorPair,
				GeneVectorPair,DiseaseVectorPair)
			# use SharedAttributeRepresentationLearningGen to generate the shared attribute representations
			# of Molecular Structure Target, Enzyme, Pathway, Side Effect, Phenotype, Gene, and Disease representations
			# of an adverse drug pair. The input of SharedAttributeRepresentationLearningGen is the attribute 
			# representations of adverse drug pairs in terms of eight attributes

			DiscriminatorLoss=SharedAttributeRepresentationLearningDis(SharedMolecularStructureVectorPair,
				SharedTargetVectorPair,SharedEnzymeVectorPair,SharedPathwayVectorPair,SharedSideEffectVectorPair,
				SharedPhenotypeVectorPair,SharedGeneVectorPair,SharedDiseaseVectorPair)
			# use SharedAttributeRepresentationLearningDis to discriminate the generated shared attribute representations
			# of each pair of attributes and output the consensus score based on the discriminator. To be specific, 
			# the designed discriminator seek to discriminate each pair of attribute based on the weight Tensor
			# AttributeInteractionTensor to minimize the consensus score

			AttributeInteractionTensor=SharedAttributeRepresentationLearningDis.state_dict()['AttributeInteractionTensor'].data
			# extract weight Tensor AttributeInteractionTensor from discriminator, which is used to calculate 
			# the consensus score based on the shared attribute attribute representations of eight attributes
			# provided by the generators
			# this Tensor is defined in class SharedAttributeRepresentationLearningDiscriminator of 
			# SharedAttributeRepresentationLearning.py
			ConsensusScoreGeneratorLoss=GeneratorConsensusScore(SharedMolecularStructureVectorPair,SharedTargetVectorPair,
				SharedEnzymeVectorPair,SharedPathwayVectorPair,SharedSideEffectVectorPair,
				SharedPhenotypeVectorPair,SharedGeneVectorPair,SharedDiseaseVectorPair,AttributeInteractionTensor)
			# use the shared attribute representations of eight attributes to calculate the consensus score
			# this function is defined in SharedAttributeRepresentationLearning.py
			# based on AttributeInteractionTensor, GeneratorConsensusScore is to compute the consensus score on each pair 
			# of attribute that aims to maximize the consensus score for capturing their consistent properties 
			# in ADDI modeling

			# in the GAN framework for shared attribute representation learning 
			# we first optimize discriminator and then optimize generator to explore the shared attribute 
			# representations of eight attributes for presenting their accordant contributions in ADDI prediction
			Option_Discriminator.zero_grad()
			# set the gradient of Option_Discriminator to be zero 
			DiscriminatorLoss.backward(retain_graph=True)
			# use the DiscriminatorLoss (the consensus score by Discriminator) for backpropagation
			Option_Discriminator.step()
			# use the model parameters (e.g., learning rate, weight_decay) for discriminator optimization

			Option_Generator.zero_grad()
			# set the gradient of Option_Generator to be zero 
			ConsensusScoreGeneratorLoss.backward(retain_graph=True)
			# use the ConsensusScoreGeneratorLoss (the consensus score by generators) for backpropagation
			Option_Generator.step()
			# use the model parameters (e.g., learning rate, weight_decay) for generator optimization

	save_path_SharedDiscriminator='SharedAttributeRepresentationLearning_Discriminator.txt'
	torch.save(SharedAttributeRepresentationLearningDis.state_dict(), save_path_SharedDiscriminator)
	# after training, we output the model parameters of the Discriminator and save them 
	# at the file of SharedAttributeRepresentationLearning_Discriminator.txt

	save_path_SharedGenerator='SharedAttributeRepresentationLearning_Generators.txt'
	torch.save(SharedAttributeRepresentationLearningGen.state_dict(), save_path_SharedGenerator)	
	# after training, we output the model parameters of the Generators and save them 
	# at the file of SharedAttributeRepresentationLearning_Generators.txt

	# Notice !!!! due to that the training process will take several days to get the final Generators
	# and Discriminator, we output them in the file for convenience of the following obtaining the 
	# generated shared and specific attribute representations for training the deep neural network for 
	# ADDI modeling and using the trained Generators and and Discriminator to predict the adverse interactions
	# of testing dataset
	print('Generator and Discriminator for Shared Attribute Representation Learning Has Been Trained Completely!!!')
	print('The Generators for Shared Attribute Representation Learning is output at SharedAttributeRepresentationLearning_Generators.txt')
	print('The Discriminator for Shared Attribute Representation Learning is output at SharedAttributeRepresentationLearning_Discriminator.txt')

	return SharedAttributeRepresentationLearningGen,SharedAttributeRepresentationLearningDis
	# return the trained generators and discriminator for shared attribute representation learning


# Training Module to capture the generators and discriminator for specific attribute 
# representation learning, in which generators G_{b}^m and G_{b}^n aim at minimizing 
# complementary score Q^{mn}_{ij} for capturing the uniqueness between the m-th 
# and the n-th attributes and exploiting their distinctive characteristics in ADDI modeling, 
# while discriminator D_{b}^{mn} seeks to maximize Q^{mn}_{ij}. the designed generators 
# and discriminator are also associated with opposite optimization objectives, 
# implying that the generated specific attribute representations G_{b}^m(H^m_{ij}) and 
# G_{b}^n(H^n_{ij}) tries to deceive discriminator D_{b}^{mn} such that the derived 
# G_{b}^m(H^m_{ij}) and G_{b}^n(H^n_{ij}) in the final state can be as unique as 
# possible by minimizing their complementary scores for presenting their unique properties 
# in ADDI prediction.
def TrainingModuleForSpecificAttributeRepresentationLearningWithGeneratorAndDiscriminator(
	AdverseInteractionTrainingList,ReconstructionMolecularStructureMatrix,ReconstructedTargetMatrix,
	ReconstructedEnzymeMatrix,ReconstructedPathwayMatrix,ReconstructedSideEffectMatrix,
	ReconstructedPhenotypeMatrix,ReconstructedGeneMatrix,ReconstructedDiseaseMatrix):
# input: AdverseInteractionTrainingList is the adverse interactions among drugs for training
# ReconstructionMolecularStructureMatrix,ReconstructedTargetMatrix,	ReconstructedEnzymeMatrix,
# ReconstructedPathwayMatrix,ReconstructedSideEffectMatrix,ReconstructedPhenotypeMatrix,
# ReconstructedGeneMatrix,and ReconstructedDiseaseMatrix are reconstructed Molecular 
# Structure, Target, Enzyme, Pathway, Side Effect, Phenotype, Gene, and Disease matrices of drugs
	MolecularStructureDimension=np.shape(ReconstructionMolecularStructureMatrix)[1]
	# return the dimensionality of MolecularStructure, i.e., 881 in the paper
	TargetDimension=np.shape(ReconstructedTargetMatrix)[1]
	# return the dimensionality of Target, i.e., 1065 in the paper
	EnzymeDimension=np.shape(ReconstructedEnzymeMatrix)[1]
	# return the dimensionality of Enzyme, i.e., 497 in the paper
	PathwayDimension=np.shape(ReconstructedPathwayMatrix)[1]
	# return the dimensionality of Pathway, i.e., 396 in the paper
	SideEffectDimension=np.shape(ReconstructedSideEffectMatrix)[1]
	# return the dimensionality of SideEffect, i.e., 3687 in the paper
	PhenotypeDimension=np.shape(ReconstructedPhenotypeMatrix)[1]
	# return the dimensionality of Phenotype, i.e., 2193 in the paper
	GeneDimension=np.shape(ReconstructedGeneMatrix)[1]
	# return the dimensionality of Gene, i.e., 4683 in the paper
	DiseaseDimension=np.shape(ReconstructedDiseaseMatrix)[1]
	# return the dimensionality of Disease, i.e., 482 in the paper

	LearningRate_Generator = 0.0001
	LearningRate_Discriminator = 0.0001
	# set the initial learning rate for Generator and Discriminator as 10^{-4}
	Weight_Decay=0.000001
	# set the weight decay for Generator and Discriminator as 10^{-6}
	
	SpecificAttributeRepresentationLearningGen=SpecificAttributeRepresentationLearningGenerators(
		2*MolecularStructureDimension,2*TargetDimension,2*EnzymeDimension,2*PathwayDimension,
		2*SideEffectDimension,2*PhenotypeDimension,2*GeneDimension,2*DiseaseDimension).to(device)
	# Initialize SpecificAttributeRepresentationLearningGenerators for generating the specific attribute 
	# representations of each adverse drug pair in terms of each attribute so as to minimize the 
	# the complementary score for each pair of attributes
	# This generator is defined in SpecificAttributeRepresentationLearning.py
	# due to that concatenation operation is used to fuse the attribute representation 
	# of two drugs into the attribute representation of drug pairs, the input dimension  
	# for the generators in terms of eight attribute are 2*dimension(attribute)
	# .to(device) is to load the neural network into cuda
	SpecificAttributeRepresentationLearningDis=SpecificAttributeRepresentationLearningDiscriminator().to(device)
	# Initialize SpecificAttributeRepresentationLearningDiscriminator for discriminating the generated
	# the specific attribute representations for maximizing the complementary score of each pair of attributes
	# to exploit their unique properties in ADDI modeling

	Option_Generator=torch.optim.Adam(SpecificAttributeRepresentationLearningGen.parameters(),
		lr=LearningRate_Generator,weight_decay=Weight_Decay)
	# set the learning rate, weight_decay of the Generators
	Option_Discriminator=torch.optim.Adam(SpecificAttributeRepresentationLearningDis.parameters(),
		lr=LearningRate_Discriminator,weight_decay=Weight_Decay)
	# set the learning rate, weight_decay of the Discriminator
	print('Training Generator and Discriminator for Specific Attribute Representation Learning!!!')
	MaxIter=50
	# set the number of iterations to be 50
	for Iter in range(MaxIter):
		# for each iteration
		for ADDISample in AdverseInteractionTrainingList:
		# traverse each sample in the training set AdverseInteractionTrainingList
			DrugID1=ADDISample.DrugID1
			DrugID2=ADDISample.DrugID2
			print('%d Iterations For Specific Attribute Representation Learning: Train Adverse Drug Pair (%d, %d)' %(Iter,DrugID1,DrugID2))
			# get two drug indexes of the adverse drug pair
			AdverseInteractionVector=ADDISample.AdverseInteractionVector
			# get the adverse interaction vector of adverse drug pair (DrugID1,DrugID2)
			MolecularStructureVectorPair=torch.cat((ReconstructionMolecularStructureMatrix[DrugID1],
				ReconstructionMolecularStructureMatrix[DrugID2]),0)
			# ReconstructionMolecularStructureMatrix[DrugID1] is the reconstructed Molecular Structure 
			# vector of DrugID1, ReconstructionMolecularStructureMatrix[DrugID2] is the reconstructed
			# Molecular Structure vector of DrugID2. Based on concatenation operation, we obtain the  
			# reconstructed Molecular Structure representation of adverse drug pair (DrugID1, DrugID2)
			# as MolecularStructureVectorPair. torch.cat( ,0) is the concatenation operation in the first dimension. 
			TargetVectorPair=torch.cat((ReconstructedTargetMatrix[DrugID1],ReconstructedTargetMatrix[DrugID2]),0)
			# ReconstructedTargetMatrix[DrugID1] is the reconstructed Target vector of DrugID1, 
			# ReconstructionMolecularStructureMatrix[DrugID2] is the reconstructed Target vector of DrugID2, 
			# Based on concatenation operation, we obtain the  reconstructed Target representation 
			# of adverse drug pair (DrugID1, DrugID2) as TargetVectorPair.
			EnzymeVectorPair=torch.cat((ReconstructedEnzymeMatrix[DrugID1],ReconstructedEnzymeMatrix[DrugID2]),0)
			# concatenate the reconstructed Enzyme vector of DrugID1 and DrugID2 into the reconstructed 
			# Enzyme representations of adverse drug pair (DrugID1, DrugID2)
			PathwayVectorPair=torch.cat((ReconstructedPathwayMatrix[DrugID1],ReconstructedPathwayMatrix[DrugID2]),0)
			# concatenate the reconstructed Pathway vector of DrugID1 and DrugID2 into the reconstructed 
			# Pathway representations of adverse drug pair (DrugID1, DrugID2)
			SideEffectVectorPair=torch.cat((ReconstructedSideEffectMatrix[DrugID1],ReconstructedSideEffectMatrix[DrugID2]),0)
			# concatenate the reconstructed SideEffect vector of DrugID1 and DrugID2 into the reconstructed 
			# SideEffect representations of adverse drug pair (DrugID1, DrugID2)
			PhenotypeVectorPair=torch.cat((ReconstructedPhenotypeMatrix[DrugID1],ReconstructedPhenotypeMatrix[DrugID2]),0)
			# concatenate the reconstructed Phenotype vector of DrugID1 and DrugID2 into the reconstructed 
			# Phenotype representations of adverse drug pair (DrugID1, DrugID2)
			GeneVectorPair=torch.cat((ReconstructedGeneMatrix[DrugID1],ReconstructedGeneMatrix[DrugID2]),0)
			# concatenate the reconstructed Gene vector of DrugID1 and DrugID2 into the reconstructed 
			# Gene representations of adverse drug pair (DrugID1, DrugID2)
			DiseaseVectorPair=torch.cat((ReconstructedDiseaseMatrix[DrugID1],ReconstructedDiseaseMatrix[DrugID2]),0)
			# concatenate the reconstructed Disease vector of DrugID1 and DrugID2 into the reconstructed 
			# Disease representations of adverse drug pair (DrugID1, DrugID2)	

			SpecificMolecularStructureVectorPair,SpecificTargetVectorPair,SpecificEnzymeVectorPair,\
			SpecificPathwayVectorPair,SpecificSideEffectVectorPair,SpecificPhenotypeVectorPair,SpecificGeneVectorPair,\
			SpecificDiseaseVectorPair=SpecificAttributeRepresentationLearningGen(MolecularStructureVectorPair,
				TargetVectorPair,EnzymeVectorPair,PathwayVectorPair,SideEffectVectorPair,PhenotypeVectorPair,
				GeneVectorPair,DiseaseVectorPair)
			# use SpecificAttributeRepresentationLearningGen to generate the specific attribute representations
			# of Molecular Structure Target, Enzyme, Pathway, Side Effect, Phenotype, Gene, and Disease representations
			# of an adverse drug pair. The input of SpecificAttributeRepresentationLearningGen is the attribute 
			# representations of adverse drug pairs in terms of eight attributes

			DiscriminatorLoss=SpecificAttributeRepresentationLearningDis(SpecificMolecularStructureVectorPair,
				SpecificTargetVectorPair,SpecificEnzymeVectorPair,SpecificPathwayVectorPair,SpecificSideEffectVectorPair,
				SpecificPhenotypeVectorPair,SpecificGeneVectorPair,SpecificDiseaseVectorPair)
			# use SpecificAttributeRepresentationLearningDis to discriminate the generated specific attribute 
			# representations of each pair of attributes and output the complementary score based on the discriminator. 
			# To be specific, the designed discriminator seek to discriminate each pair of attribute based on the 
			# weight TensorAttributeInteractionTensor to maximize the complementary score

			AttributeInteractionTensor=SpecificAttributeRepresentationLearningDis.state_dict()['AttributeInteractionTensor'].data
			# extract weight Tensor AttributeInteractionTensor from discriminator, which is used to calculate 
			# the complementary score based on the specific attribute attribute representations of eight attributes
			# provided by the generators
			# this Tensor is defined in class SpecificAttributeRepresentationLearningDiscriminator of 
			# SpecificAttributeRepresentationLearning.py
			ComplementaryScoreGeneratorLoss=GeneratorComplementaryScore(SpecificMolecularStructureVectorPair,SpecificTargetVectorPair,
				SpecificEnzymeVectorPair,SpecificPathwayVectorPair,SpecificSideEffectVectorPair,SpecificPhenotypeVectorPair,
				SpecificGeneVectorPair,SpecificDiseaseVectorPair,AttributeInteractionTensor)
			# use the specific attribute representations of eight attributes to calculate the complementary score
			# this function is defined in SpecificAttributeRepresentationLearning.py
			# based on AttributeInteractionTensor, GeneratorComplementaryScore is to compute the complementary score 
			# on each pair of attribute that aims to minimize the complementary score for capturing their unique properties 
			# in ADDI modeling

			# in the GAN framework for specific attribute representation learning 
			# we first optimize discriminator and then optimize generator to explore the specific attribute 
			# representations of eight attributes for presenting their distinctive characteristics in ADDI prediction
			Option_Discriminator.zero_grad()
			# set the gradient of Option_Discriminator to be zero 
			DiscriminatorLoss.backward(retain_graph=True)
			# use the DiscriminatorLoss (the complementary score by Discriminator) for backpropagation
			Option_Discriminator.step()
			# use the model parameters (e.g., learning rate, weight_decay) for discriminator optimization

			Option_Generator.zero_grad()
			# set the gradient of Option_Generator to be zero 
			ComplementaryScoreGeneratorLoss.backward(retain_graph=True)
			# use the ComplementaryScoreGeneratorLoss (the complementary score by generators) for backpropagation
			Option_Generator.step()
			# use the model parameters (e.g., learning rate, weight_decay) for generator optimization

	save_path_SpecificDiscriminator='SpecificAttributeRepresentationLearning_Discriminator.txt'
	torch.save(SpecificAttributeRepresentationLearningDis.state_dict(), save_path_SpecificDiscriminator)
	# after training, we output the model parameters of the Discriminator and save them 
	# at the file of SpecificAttributeRepresentationLearning_Discriminator.txt

	save_path_SpecificGenerator='SpecificAttributeRepresentationLearning_Generators.txt'
	torch.save(SpecificAttributeRepresentationLearningGen.state_dict(), save_path_SpecificGenerator)	
	# after training, we output the model parameters of the Generators and save them 
	# at the file of SpecificAttributeRepresentationLearning_Generators.txt

	# Notice !!!! due to that the training process will take several days to get the final Generators
	# and Discriminator, we output them in the file for convenience of the following obtaining the 
	# generated shared and specific attribute representations for training the deep neural network for 
	# ADDI modeling and using the trained Generators and and Discriminator to predict the adverse interactions
	# of testing dataset
	print('Generator and Discriminator for Specific Attribute Representation Learning Has Been Trained Completely!!!')
	print('The Generators for Specific Attribute Representation Learning is output at SpecificAttributeRepresentationLearning_Generators.txt')
	print('The Discriminator for Specific Attribute Representation Learning is output at SpecificAttributeRepresentationLearning_Discriminator.txt')

	# return the trained generators and discriminator for specific attribute representation learning
	return SpecificAttributeRepresentationLearningGen,SpecificAttributeRepresentationLearningDis


# This function is to use shared attribute representations and specific attribute representations
# of adverse drug pairs in terms of eight attributes for ADDI modeling. Based on the generators of 
# shared and specific attribute representation learning, the attribute representations of each adverse 
# drug pair in terms of eight attributes can be mapped into their shared attribute representations and 
# specific attribute representations. We average shared attribute representations of eight attributes and derive the final shared attribute 
# representation of adverse drug pair and align specific attribute representations of eight attributes and get the final specific 
# attribute representation of (d_i, d_j). Based on concatenation operation, we align the averaged shared attribute 
# representation and the aligned specific attribute representation and obtain the final attribute representation as the 
#input of the deep neural network for ADDI modeling
def TrainingModuleForMultiAttributeNeuralNetworkForADDIModeling(AdverseInteractionTrainingList,
	ReconstructionMolecularStructureMatrix,ReconstructedTargetMatrix,ReconstructedEnzymeMatrix,
	econstructedPathwayMatrix,ReconstructedSideEffectMatrix,ReconstructedPhenotypeMatrix,
	ReconstructedGeneMatrix,ReconstructedDiseaseMatrix):
# input: AdverseInteractionTrainingList is the adverse interactions among drugs for training
# ReconstructionMolecularStructureMatrix,ReconstructedTargetMatrix,ReconstructedEnzymeMatrix,
# ReconstructedPathwayMatrix,ReconstructedSideEffectMatrix,ReconstructedPhenotypeMatrix,
# ReconstructedGeneMatrix,ReconstructedDiseaseMatrix are the reconstructed Molecular 
# Structure, Target, Enzyme, Pathway, Side Effect, Phenotype, Gene, and Disease matrices of drugs
# Notice!!! SharedAttributeRepresentationLearningGen and SpecificAttributeRepresentationLearningGen can 
# be directly used for outputing shared and specific attribute representations for training the deep neural 
# network for ADDI modeling. Here, we load them from files 'SharedAttributeRepresentationLearning_Generators.txt'
# and 'SpecificAttributeRepresentationLearning_Generators.txt' to achieve the above issue. 
	MolecularStructureDimension=np.shape(ReconstructionMolecularStructureMatrix)[1]
	# return the dimensionality of MolecularStructure, i.e., 881 in the paper
	TargetDimension=np.shape(ReconstructedTargetMatrix)[1]
	# return the dimensionality of Target, i.e., 1065 in the paper
	EnzymeDimension=np.shape(ReconstructedEnzymeMatrix)[1]
	# return the dimensionality of Enzyme, i.e., 497 in the paper
	PathwayDimension=np.shape(ReconstructedPathwayMatrix)[1]
	# return the dimensionality of Pathway, i.e., 396 in the paper
	SideEffectDimension=np.shape(ReconstructedSideEffectMatrix)[1]
	# return the dimensionality of SideEffect, i.e., 3687 in the paper
	PhenotypeDimension=np.shape(ReconstructedPhenotypeMatrix)[1]
	# return the dimensionality of Phenotype, i.e., 2193 in the paper
	GeneDimension=np.shape(ReconstructedGeneMatrix)[1]
	# return the dimensionality of Gene, i.e., 4683 in the paper
	DiseaseDimension=np.shape(ReconstructedDiseaseMatrix)[1]
	# return the dimensionality of Disease, i.e., 482 in the paper
	save_path_SharedGenerator='SharedAttributeRepresentationLearning_Generators.txt'
	# get the address of the generator for the shared attribute representation learning
	
	SharedAttributeRepresentationLearningGen_ADDIModeling=SharedAttributeRepresentationLearningGenerators(
		2*MolecularStructureDimension,2*TargetDimension,2*EnzymeDimension,2*PathwayDimension,
		2*SideEffectDimension,2*PhenotypeDimension,2*GeneDimension,2*DiseaseDimension).to(device)
	# Initialize generators for shared attribute representation learning
	SharedAttributeRepresentationLearningGen_ADDIModeling.load_state_dict(
		torch.load(save_path_SharedGenerator))
	# load the model parameter to recover the generators for shared attribute representation learning
	# SharedAttributeRepresentationLearningGen_ADDIModeling=SharedAttributeRepresentationLearningGen
	
	SharedAttributeRepresentationLearningGen_ADDIModeling.eval()
	# this code is equivalent to evaluation that outputs the generated the shared attribute representations
	# of all training adverse drug pairs 
	save_path_SpecificGenerator='SpecificAttributeRepresentationLearning_Generators.txt'
	# get the address of the generator for the specific attribute representation learning
	SpecificAttributeRepresentationLearningGen_ADDIModeling=SpecificAttributeRepresentationLearningGenerators(
		2*MolecularStructureDimension,2*TargetDimension,2*EnzymeDimension,2*PathwayDimension,
		2*SideEffectDimension,2*PhenotypeDimension,2*GeneDimension,2*DiseaseDimension).to(device)
	# Initialize generators for specific attribute representation learning
	SpecificAttributeRepresentationLearningGen_ADDIModeling.load_state_dict(
		torch.load(save_path_SpecificGenerator))
	# load the model parameter to recover the generators for specific attribute representation learning
	# SpecificAttributeRepresentationLearningGen_ADDIModeling=SpecificAttributeRepresentationLearningGen

	SpecificAttributeRepresentationLearningGen_ADDIModeling.eval()
	# this code is equivalent to evaluation that outputs the generated the specific attribute representations
	# of all training adverse drug pairs 
	fileOut=open('FinalAttributeRepresentationOfTrainingSamples.txt','w')
	# open a file to store the Final attribute representations of all Training samples

	FinalAttributeVectorOfTrainingSamples=torch.empty(size=[1,320])
	# Initialize a Tensor to record the final attribute representations of all training samples
	# the size of Tensor is Number of training samples * 320 (320 is the dimension of the final 
	# attribute representations, where the dimension of shared attribute representation is 64 and 
	# the dimension of the specific attribute representation is 32*8)
	for ADDISample in AdverseInteractionTrainingList:
	# traverse each sample in the training set AdverseInteractionTrainingList
		DrugID1=ADDISample.DrugID1
		DrugID2=ADDISample.DrugID2
		# get two drug indexes of the adverse drug pair
		MolecularStructureVectorPair=torch.cat((ReconstructionMolecularStructureMatrix[DrugID1],
			ReconstructionMolecularStructureMatrix[DrugID2]),0)
		# concatenate the reconstructed MolecularStructure vector of DrugID1 and DrugID2 into the reconstructed 
		# MolecularStructure representations of adverse drug pair (DrugID1, DrugID2)
		TargetVectorPair=torch.cat((ReconstructedTargetMatrix[DrugID1],ReconstructedTargetMatrix[DrugID2]),0)
		# concatenate the reconstructed Target vector of DrugID1 and DrugID2 into the reconstructed 
		# Target representations of adverse drug pair (DrugID1, DrugID2)
		EnzymeVectorPair=torch.cat((ReconstructedEnzymeMatrix[DrugID1],ReconstructedEnzymeMatrix[DrugID2]),0)
		# concatenate the reconstructed Enzyme vector of DrugID1 and DrugID2 into the reconstructed 
		# Enzyme representations of adverse drug pair (DrugID1, DrugID2)
		PathwayVectorPair=torch.cat((ReconstructedPathwayMatrix[DrugID1],ReconstructedPathwayMatrix[DrugID2]),0)
		# concatenate the reconstructed Pathway vector of DrugID1 and DrugID2 into the reconstructed 
		# Pathway representations of adverse drug pair (DrugID1, DrugID2)
		SideEffectVectorPair=torch.cat((ReconstructedSideEffectMatrix[DrugID1],ReconstructedSideEffectMatrix[DrugID2]),0)
		# concatenate the reconstructed SideEffect vector of DrugID1 and DrugID2 into the reconstructed 
		# SideEffect representations of adverse drug pair (DrugID1, DrugID2)
		PhenotypeVectorPair=torch.cat((ReconstructedPhenotypeMatrix[DrugID1],ReconstructedPhenotypeMatrix[DrugID2]),0)
		# concatenate the reconstructed Phenotype vector of DrugID1 and DrugID2 into the reconstructed 
		# Phenotype representations of adverse drug pair (DrugID1, DrugID2)
		GeneVectorPair=torch.cat((ReconstructedGeneMatrix[DrugID1],ReconstructedGeneMatrix[DrugID2]),0)
		# concatenate the reconstructed Gene vector of DrugID1 and DrugID2 into the reconstructed 
		# Gene representations of adverse drug pair (DrugID1, DrugID2)
		DiseaseVectorPair=torch.cat((ReconstructedDiseaseMatrix[DrugID1],ReconstructedDiseaseMatrix[DrugID2]),0)
		# concatenate the reconstructed Disease vector of DrugID1 and DrugID2 into the reconstructed 
		# Disease representations of adverse drug pair (DrugID1, DrugID2)	

		SharedMolecularStructureVectorPair,SharedTargetVectorPair,SharedEnzymeVectorPair,\
		SharedPathwayVectorPair,SharedSideEffectVectorPair,SharedPhenotypeVectorPair,SharedGeneVectorPair,\
		SharedDiseaseVectorPair=SharedAttributeRepresentationLearningGen_ADDIModeling(MolecularStructureVectorPair,
			TargetVectorPair,EnzymeVectorPair,PathwayVectorPair,SideEffectVectorPair,PhenotypeVectorPair,
			GeneVectorPair,DiseaseVectorPair)
		# get the shared attribute representations of each adverse drug pair in terms of Molecular Structure, 
		# Target, Enzyme, Pathway, Side Effect, Phenotype, Gene, and Disease

		SpecificMolecularStructureVectorPair,SpecificTargetVectorPair,SpecificEnzymeVectorPair,\
		SpecificPathwayVectorPair,SpecificSideEffectVectorPair,SpecificPhenotypeVectorPair,SpecificGeneVectorPair,\
		SpecificDiseaseVectorPair=SpecificAttributeRepresentationLearningGen_ADDIModeling(MolecularStructureVectorPair,
			TargetVectorPair,EnzymeVectorPair,PathwayVectorPair,SideEffectVectorPair,PhenotypeVectorPair,
			GeneVectorPair,DiseaseVectorPair)
		# get the specific attribute representations of each adverse drug pair in terms of Molecular Structure, 
		# Target, Enzyme, Pathway, Side Effect, Phenotype, Gene, and Disease

		AveragedSharedAttributeVectorPair=(SharedMolecularStructureVectorPair+SharedTargetVectorPair+\
			SharedEnzymeVectorPair+SharedPathwayVectorPair+SharedSideEffectVectorPair+\
			SharedPhenotypeVectorPair+SharedGeneVectorPair+SharedDiseaseVectorPair)/8
		# average the shared Attribute representations of eight attributes

		AlignSpecificAttributeVectorPair=torch.cat((SpecificMolecularStructureVectorPair,
			SpecificTargetVectorPair,SpecificEnzymeVectorPair,SpecificPathwayVectorPair,
			SpecificSideEffectVectorPair,SpecificPhenotypeVectorPair,SpecificGeneVectorPair,
			SpecificDiseaseVectorPair),0)
		# align the	specific attribute representations of eight attributes into the attribute 
		# representation with the length of 32*8

		FinalAttributeVectorPair=torch.cat((AveragedSharedAttributeVectorPair,
			AlignSpecificAttributeVectorPair),0)
		# align the shared and specific attribute representations into the final attribute 
		# representation with the length of 64+32*8

		FinalAttributeVectorPair=FinalAttributeVectorPair.view(1,-1)
		# reshape Tensor vector FinalAttributeVectorPair with the length of 320 into a tensor with size of 1*320
		FinalAttributeVectorOfTrainingSamples=torch.cat((FinalAttributeVectorOfTrainingSamples,
			FinalAttributeVectorPair),0)
		# store the final attribute representations of adverse drug pair (DrugID1,DrugID2) into tensor 
		# FinalAttributeVectorOfTrainingSamples
		print('Output Final Attribute Representation of Adverse Drug pair (%d, %d)' %(DrugID1,DrugID2))
		print('%d\t%d\n' %(DrugID1,DrugID2),end='', file=fileOut)
		print(FinalAttributeVectorPair, end='', file=fileOut)
		print('\n', end='', file=fileOut)
		# print the drug indexes of all adverse drug pairs with their final attribute representation
		# that is integrated by their average shared Attribute representations and aligned the specific 
		# attribute representations of eight attributes. The detailed final attribute representations
		# of all training samples are recorded at FinalAttributeRepresentationOfTrainingSamples.txt
	fileOut.flush()
	fileOut.close()

	FinalAttributeVectorOfTrainingSamples=FinalAttributeVectorOfTrainingSamples[torch.arange(
		FinalAttributeVectorOfTrainingSamples.size(0))!=0]
	# remove the first random vector from FinalAttributeVectorOfTrainingSamples and maintain the last 2-
	# len(AdverseInteractionTrainingList) final attribute representations in FinalAttributeVectorOfTrainingSamples

	FinalAttributeVectorOfTrainingSamples=FinalAttributeVectorOfTrainingSamples.detach().numpy()
	# convert tensor FinalAttributeVectorOfTrainingSamples into numpy for outputing the numpy 
	# by np.save(FinalAttributeVectorOfTrainingSamples)
	np.save('FinalAttributeRepresentationOfTrainingSamples',FinalAttributeVectorOfTrainingSamples)
	# save FinalAttributeRepresentationOfTrainingSamples by np.save. However, this npy file cannot be read 
	# directly but can be loaded by np.load. The detailed information of final attribute representation of training
	# samples can be found in FinalAttributeRepresentationOfTrainingSamples.txt
	print('The Final Attribute Representations of All Training Samples are output at '+\
		'Files FinalAttributeRepresentationOfTrainingSamples.txt and FinalAttributeRepresentationOfTrainingSamples.npy')

	# the following codes are used to Training the deep neural network for ADDI modeling
	# in which a the final attribute representation of each Training Adverse drug pair 
	# (DrugID1, DrugID2) (i.e., d_i, d_j) is regarded the input of the neural network and the, and the their 
	# ground-truth Adverse interaction vector r_{ij}^K is seen as the output of the neural network
	# K is the number of adverse interactions. In other word, the output dimension of the neural network 
	# is same to the number of Adverse interactions (K=258). 
	LearningRate_DeepNeuralNetwork = 0.0001
	# set the initial learning rate for deep neural network as 10^{-4}
	Weight_Decay_DeepNeuralNetwork=0.000001
	# set the weight decay for deep neural network as 10^{-6}
	DimensionOfFinalAttributeRepresentation=np.shape(FinalAttributeVectorOfTrainingSamples)[1]
	# get the dimension of the final attribute representation of an Adverse drug pair, i.e., 320
	DimensionOfAdverseInteraction=(AdverseInteractionTrainingList[0].
		AdverseInteractionVector).size()[0]
	# get the dimension of the number of adverse interaction (K=258)
	DeepNeuralNetwork=DeepNeuralNetworkForADDIModeling(DimensionOfFinalAttributeRepresentation,
		DimensionOfAdverseInteraction)
	# Initializing the deep neural network for training the underlying relation between the 
	# final attribute representation of adverse drug pair and its adverse interaction vector
	#this deep neural network is defined in MultiAttributeLearningForADDIPrediction.py 
	Option_DeepNeuralNetwork=torch.optim.Adam(DeepNeuralNetwork.parameters(),
		lr=LearningRate_DeepNeuralNetwork,weight_decay=Weight_Decay_DeepNeuralNetwork)
	# set the learning rate, weight_decay of the DeepNeuralNetwork
	FinalAttributeVectorOfTrainingSamples=torch.Tensor(FinalAttributeVectorOfTrainingSamples)
	# convert numpy FinalAttributeVectorOfTrainingSamples into torch
	MaxIter=50
	# set the number of iterations to be 50
	for Iter in range(MaxIter):
		# for each iteration
		Index=0
		# index records the number of row in FinalAttributeVectorOfTrainingSamples
		# to be specific, the final attribute representation of the index-th sample 
		# in AdverseInteractionTrainingList is FinalAttributeVectorOfTrainingSamples[index]
		for ADDISample in AdverseInteractionTrainingList:
		# traverse each sample in the training set AdverseInteractionTrainingList
			DrugID1=ADDISample.DrugID1
			DrugID2=ADDISample.DrugID2
			print('%d Iterations For Training Deep Network Network: Adverse Drug Pair (%d, %d)' %(Iter,DrugID1,DrugID2))	
			AdverseInteractionVector=ADDISample.AdverseInteractionVector
			# get the adverse interaction vector of adverse drug pair (DrugID1,DrugID2)
			FinalAttributeRepresentationOfDrugID12=FinalAttributeVectorOfTrainingSamples[Index]
			# get the final attribute representation of adverse drug pair (DrugID1,DrugID2)
			Index=Index+1
			PredictedAdverseInteractionVector=DeepNeuralNetwork(FinalAttributeRepresentationOfDrugID12)
			# use DeepNeuralNetwork to train the neural network with the input of the final attribute 
			# representation FinalAttributeRepresentationOfDrugID12of Adverse drug pair (DrugID1,DrugID2) 
			# to output its prediced adverse interaction vector
			DeepNeuralNetworkLoss=LossFunctionOfPredictedAndGroundTruthAdverseInteractionVector(PredictedAdverseInteractionVector, 
				AdverseInteractionVector)
			# call function LossFunctionOfPredictedAndGroundTruthAdverseInteractionVector to calculate the loss 
			# between the predicted Adverse interaction vector and the ground-truth Adverse interaction 
			# vector of an Adverse drug pair
			Option_DeepNeuralNetwork.zero_grad()
			# set the gradient of Option_DeepNeuralNetwork to be zero 
			DeepNeuralNetworkLoss.backward(retain_graph=True)
			# use DeepNeuralNetworkLoss for backpropagation
			Option_DeepNeuralNetwork.step()
			# use model parameters (learning rate, weight_decay) for DeepNeuralNetwork optimization

	save_path_DeepNeuralNetwork='DeepNeuralNetworkForADDIModeling.txt'
	# open a file to store the model parameters of the trained deep neural network
	torch.save(DeepNeuralNetwork.state_dict(), save_path_DeepNeuralNetwork)
	# after training, we output the model parameters of the DeepNeuralNetwork and save them 
	# at the file of DeepNeuralNetworkForADDIModeling.txt
	print('The Deep Neural Network Has Been Trained Completely!!!')
	return DeepNeuralNetwork

# this function is to convert a float matrix into a binary matrix. To be specific, if 
# a element is higher than the threshold, we set it to be 1, otherwise set it to be 0
def ConvertBinaryMatrix(TempMatrix):
# Input: TempMatrix is the matrix to be converted
	RowNum,ColumnNum=np.shape(TempMatrix)
	TempMatrixConvertedBinary=np.zeros((RowNum,ColumnNum))
	# Initialize a matrix with the size of RowNum*ColumnNum by all zeros
	Threshold_PredictADDI=0.5
	# set the threshold to convert TempMatrix into a binary matrix
	for i in range(RowNum):
		for j in range(ColumnNum):
		# traverse each element in matrix TempMatrix
			if TempMatrix[i,j]>=Threshold_PredictADDI:
				TempMatrixConvertedBinary[i,j]=1
			# TempMatrixConvertedBinary is derived by the Threshold_PredictADDI
			# if element TempMatrix[i,j] is higher than Threshold_PredictADDI
			# TempMatrixConvertedBinary[i,j]=1
			elif TempMatrix[i,j]<Threshold_PredictADDI:
				TempMatrixConvertedBinary[i,j]=0
			# if element TempMatrix[i,j] is less than Threshold_PredictADDI
			# TempMatrixConvertedBinary[i,j]=0
	return TempMatrixConvertedBinary


# this function is to output the evaluation metrics for validating the performance of the 
# proposed model. The evaluation metrics are Specificity, Precision, Recall, 
# F-score, Accuracy, AUC, and AUPR. This function is to return the seven metrics for model 
# evaluation
def EvaluationModuleForComputingSevenMetrics(GroundTruthAdverseInteractionOfTestingSet,
	PredictedAdverseInteractionOfTestingSet):
	TestSamplesNumber, DimensionOfAdverseInteraction=np.shape(PredictedAdverseInteractionOfTestingSet)
	# get the number of rows and columns of the Testing Matrices, i.e., GroundTruthAdverseInteractionOfTestingSet
	# and PredictedAdverseInteractionOfTestingSet
	PredictedAdverseInteractionOfTestingSetBinary=ConvertBinaryMatrix(PredictedAdverseInteractionOfTestingSet)
	# convert PredictedAdverseInteractionOfTestingSet into a binary matrix by function ConvertBinaryMatrix
	tn, fp, tp, fn =confusion_matrix(GroundTruthAdverseInteractionOfTestingSet.flatten(),
		PredictedAdverseInteractionOfTestingSetBinary.flatten()).ravel()
	# we first flatten the ground-truth Adverse Interaction matrix of testing samples and the predicted Adverse Interaction 
	# matrix of testing samples into Vectors and then use confusion_matrix function to calculate tn, fp, fn, tp values of 
	# confusion matrix. To be specific, tn refers to true negative (0 is predicted as 0), fp refers to false positive (0 is 
	# predicted as 1), tp refers to true positive (1 is predicted as 1), and fn refers to false negative (1 is predicted as 0)
	AUC=roc_auc_score(GroundTruthAdverseInteractionOfTestingSet.flatten(),
		PredictedAdverseInteractionOfTestingSetBinary.flatten())
	# call function roc_auc_score to estimate the AUC value of the model 
	# here, we also have to flatten matrices GroundTruthAdverseInteractionOfTestingSet
	# and PredictedAdverseInteractionOfTestingSetBinary into Vectors
	AUPR= average_precision_score(GroundTruthAdverseInteractionOfTestingSet.flatten(),
		PredictedAdverseInteractionOfTestingSetBinary.flatten())
	# call function average_precision_score to calculate the AUPR value of the model
	# here, we also have to flatten matrices GroundTruthAdverseInteractionOfTestingSet
	# and PredictedAdverseInteractionOfTestingSetBinary into Vectors
	
	Specificity=tn/(tn+fp)
	Accuracy=(tp+tn)/(tp+tn+fp+fn)
	Precision=tp/(tp+fp)
	Recall=tp/(tp+fn)
	F_score=2*Precision*Recall/(Precision+Recall)
	# compute metrics Specificity,Accuracy,Precision,Recall,F_score based on the values
	# of tn, fp, fn, tp
	return Specificity,Precision,Recall,F_score,Accuracy,AUC,AUPR

# This function is to test the Adverse interactions among drugs in the test set 
# AdverseInteractionTestingList. Specifically, for each test adverse drug pair (DrugID1, DrugID2),
# we first use the trained generators for shared and Specific Attribute Representation Learning to  
# derive its shared and Specific Attribute Representations in terms of eight Attributes. Then, we 
# average the generated shared attribute Representations of eight attributes and align the specific 
# attribute Representations of eight attributes and get its final attribute representation by aligning
# its averaged shared attribute representation and aligned specific attribute representations. Based on 
# the trained Deep Neural Network for ADDI modeling, we use the final attribute representation of each tested
# adverse drug pair as input of deep neural network and output its predicted adverse interaction vector, which 
# is compared with its ground-truth adverse interaction vector to output the seven evaluation metrics for 
# performance validation
def TestingModuleForPredictingAdverseInteractionInTestingList(AdverseInteractionTestingList,
	econstructionMolecularStructureMatrix,ReconstructedTargetMatrix,ReconstructedEnzymeMatrix,
	ReconstructedPathwayMatrix,ReconstructedSideEffectMatrix,ReconstructedPhenotypeMatrix,
	ReconstructedGeneMatrix,ReconstructedDiseaseMatrix):
# Input: AdverseInteractionTestingList is the testing dataset
# Notice!!! the generators for shared and specific attribute representation Learning and the deep 
# neural network for ADDI modeling can be introduced into this function as parameters. 
# Here, we load the generators from files 'SharedAttributeRepresentationLearning_Generators.txt' and 
# 'SpecificAttributeRepresentationLearning_Generators.txt' and load the deep network network 
# from 'DeepNeuralNetworkForADDIModeling.txt'
# ReconstructionMolecularStructureMatrix,ReconstructedTargetMatrix,ReconstructedEnzymeMatrix,
# ReconstructedPathwayMatrix,ReconstructedSideEffectMatrix,ReconstructedPhenotypeMatrix,
# ReconstructedGeneMatrix,ReconstructedDiseaseMatrix are the reconstructed Molecular 
# Structure, Target, Enzyme, Pathway, Side Effect, Phenotype, Gene, and Disease matrices of drugs
	
	MolecularStructureDimension=np.shape(ReconstructionMolecularStructureMatrix)[1]
	# return the dimensionality of MolecularStructure, i.e., 881 in the paper
	TargetDimension=np.shape(ReconstructedTargetMatrix)[1]
	# return the dimensionality of Target, i.e., 1065 in the paper
	EnzymeDimension=np.shape(ReconstructedEnzymeMatrix)[1]
	# return the dimensionality of Enzyme, i.e., 497 in the paper
	PathwayDimension=np.shape(ReconstructedPathwayMatrix)[1]
	# return the dimensionality of Pathway, i.e., 396 in the paper
	SideEffectDimension=np.shape(ReconstructedSideEffectMatrix)[1]
	# return the dimensionality of SideEffect, i.e., 3687 in the paper
	PhenotypeDimension=np.shape(ReconstructedPhenotypeMatrix)[1]
	# return the dimensionality of Phenotype, i.e., 2193 in the paper
	GeneDimension=np.shape(ReconstructedGeneMatrix)[1]
	# return the dimensionality of Gene, i.e., 4683 in the paper
	DiseaseDimension=np.shape(ReconstructedDiseaseMatrix)[1]
	# return the dimensionality of Disease, i.e., 482 in the paper
	
	save_path_SharedGenerator='SharedAttributeRepresentationLearning_Generators.txt'
	# get the address of the generator for the shared attribute representation learning
	SharedAttributeRepresentationLearningGen_ADDIPredict=SharedAttributeRepresentationLearningGenerators(
		2*MolecularStructureDimension,2*TargetDimension,2*EnzymeDimension,2*PathwayDimension,
		2*SideEffectDimension,2*PhenotypeDimension,2*GeneDimension,2*DiseaseDimension).to(device)
	# Initialize generators for shared attribute representation learning
	SharedAttributeRepresentationLearningGen_ADDIPredict.load_state_dict(
		torch.load(save_path_SharedGenerator))
	# load the model parameter to recover the generators for shared attribute representation learning
	# SharedAttributeRepresentationLearningGen_Predict=SharedAttributeRepresentationLearningGen
	SharedAttributeRepresentationLearningGen_ADDIPredict.eval()
	# .eval() is for model evaluation
	
	save_path_SpecificGenerator='SpecificAttributeRepresentationLearning_Generators.txt'
	# get the address of the generator for the specific attribute representation learning
	SpecificAttributeRepresentationLearningGen_ADDIPredict=SpecificAttributeRepresentationLearningGenerators(
		2*MolecularStructureDimension,2*TargetDimension,2*EnzymeDimension,2*PathwayDimension,
		2*SideEffectDimension,2*PhenotypeDimension,2*GeneDimension,2*DiseaseDimension).to(device)
	# Initialize generators for specific attribute representation learning
	SpecificAttributeRepresentationLearningGen_ADDIPredict.load_state_dict(
		torch.load(save_path_SpecificGenerator))
	# load the model parameter to recover the generators for specific attribute representation learning
	# SpecificAttributeRepresentationLearningGen_ADDIModeling=SpecificAttributeRepresentationLearningGen
	SpecificAttributeRepresentationLearningGen_ADDIPredict.eval()
	# .eval() is for model evaluation
	
	save_path_DeepNeuralNetwork='DeepNeuralNetworkForADDIModeling.txt'
	# get the address of the trained deep neural network for ADDI modeling
	DimensionOfAdverseInteraction=(AdverseInteractionTestingList[0].
		AdverseInteractionVector).size()[0]
	# get the dimension of the number of adverse interaction (K=258)
	DeepNeuralNetwork_ADDIPredict=DeepNeuralNetworkForADDIModeling(32*8+64,
		DimensionOfAdverseInteraction)
	# the dimension of the final attribute representation of an Adverse drug pair is 320
	DeepNeuralNetwork_ADDIPredict.load_state_dict(torch.load(save_path_DeepNeuralNetwork))
	# load the model parameter to recover the deep neural network for predicting adverse interaction 
	# of the testing drug drug pairs 
	DeepNeuralNetwork_ADDIPredict.eval()
	print('Testing Module for Predicting Adverse Interactions in Testing Dataset!!!')

	GroundTruthAdverseInteractionOfTestingSet=torch.empty(size=[1,DimensionOfAdverseInteraction])
	# Initialize a set to record the ground-truth adverse interactions of the testing samples
	PredictedAdverseInteractionOfTestingSet=torch.empty(size=[1,DimensionOfAdverseInteraction])
	# Initialize a set to record the predicted adverse interactions of the testing samples

	for ADDISample in AdverseInteractionTestingList:
		# traverse each sample in the testing set AdverseInteractionTestingList
		DrugID1=ADDISample.DrugID1
		DrugID2=ADDISample.DrugID2
		# get two drug indexes of the adverse drug pair
		AdverseInteractionVector=ADDISample.AdverseInteractionVector
		# get the adverse interaction vector of adverse drug pair (DrugID1,DrugID2)

		MolecularStructureVectorPair=torch.cat((ReconstructionMolecularStructureMatrix[DrugID1],
			ReconstructionMolecularStructureMatrix[DrugID2]),0)
		# concatenate the reconstructed MolecularStructure vector of DrugID1 and DrugID2 into the reconstructed 
		# MolecularStructure representations of adverse drug pair (DrugID1, DrugID2)
		TargetVectorPair=torch.cat((ReconstructedTargetMatrix[DrugID1],ReconstructedTargetMatrix[DrugID2]),0)
		# concatenate the reconstructed Target vector of DrugID1 and DrugID2 into the reconstructed 
		# Target representations of adverse drug pair (DrugID1, DrugID2)
		EnzymeVectorPair=torch.cat((ReconstructedEnzymeMatrix[DrugID1],ReconstructedEnzymeMatrix[DrugID2]),0)
		# concatenate the reconstructed Enzyme vector of DrugID1 and DrugID2 into the reconstructed 
		# Enzyme representations of adverse drug pair (DrugID1, DrugID2)
		PathwayVectorPair=torch.cat((ReconstructedPathwayMatrix[DrugID1],ReconstructedPathwayMatrix[DrugID2]),0)
		# concatenate the reconstructed Pathway vector of DrugID1 and DrugID2 into the reconstructed 
		# Pathway representations of adverse drug pair (DrugID1, DrugID2)
		SideEffectVectorPair=torch.cat((ReconstructedSideEffectMatrix[DrugID1],ReconstructedSideEffectMatrix[DrugID2]),0)
		# concatenate the reconstructed SideEffect vector of DrugID1 and DrugID2 into the reconstructed 
		# SideEffect representations of adverse drug pair (DrugID1, DrugID2)
		PhenotypeVectorPair=torch.cat((ReconstructedPhenotypeMatrix[DrugID1],ReconstructedPhenotypeMatrix[DrugID2]),0)
		# concatenate the reconstructed Phenotype vector of DrugID1 and DrugID2 into the reconstructed 
		# Phenotype representations of adverse drug pair (DrugID1, DrugID2)
		GeneVectorPair=torch.cat((ReconstructedGeneMatrix[DrugID1],ReconstructedGeneMatrix[DrugID2]),0)
		# concatenate the reconstructed Gene vector of DrugID1 and DrugID2 into the reconstructed 
		# Gene representations of adverse drug pair (DrugID1, DrugID2)
		DiseaseVectorPair=torch.cat((ReconstructedDiseaseMatrix[DrugID1],ReconstructedDiseaseMatrix[DrugID2]),0)
		# concatenate the reconstructed Disease vector of DrugID1 and DrugID2 into the reconstructed 
		# Disease representations of adverse drug pair (DrugID1, DrugID2)	

		SharedMolecularStructureVectorPair,SharedTargetVectorPair,SharedEnzymeVectorPair,\
		SharedPathwayVectorPair,SharedSideEffectVectorPair,SharedPhenotypeVectorPair,SharedGeneVectorPair,\
		SharedDiseaseVectorPair=SharedAttributeRepresentationLearningGen_ADDIPredict(MolecularStructureVectorPair,
			TargetVectorPair,EnzymeVectorPair,PathwayVectorPair,SideEffectVectorPair,PhenotypeVectorPair,
			GeneVectorPair,DiseaseVectorPair)
		# use the loaded generator to output the shared attribute representations of testing adverse drug pair 
		# (DrugID1,DrugID2) in terms of eight attribute. the generator is SharedAttributeRepresentationLearningGen_ADDIPredict

		SpecificMolecularStructureVectorPair,SpecificTargetVectorPair,SpecificEnzymeVectorPair,\
		SpecificPathwayVectorPair,SpecificSideEffectVectorPair,SpecificPhenotypeVectorPair,SpecificGeneVectorPair,\
		SpecificDiseaseVectorPair=SpecificAttributeRepresentationLearningGen_ADDIPredict(MolecularStructureVectorPair,
			TargetVectorPair,EnzymeVectorPair,PathwayVectorPair,SideEffectVectorPair,PhenotypeVectorPair,
			GeneVectorPair,DiseaseVectorPair)
		# use the loaded generator to output the specific attribute representations of testing adverse drug pair 
		# (DrugID1,DrugID2) in terms of eight attribute. the generator is SpecificAttributeRepresentationLearningGen_ADDIPredict

		AveragedSharedAttributeVectorPair=(SharedMolecularStructureVectorPair+SharedTargetVectorPair+\
			SharedEnzymeVectorPair+SharedPathwayVectorPair+SharedSideEffectVectorPair+\
			SharedPhenotypeVectorPair+SharedGeneVectorPair+SharedDiseaseVectorPair)/8
		# average the shared Attribute representations of eight attributes
		AlignSpecificAttributeVectorPair=torch.cat((SpecificMolecularStructureVectorPair,
			SpecificTargetVectorPair,SpecificEnzymeVectorPair,SpecificPathwayVectorPair,
			SpecificSideEffectVectorPair,SpecificPhenotypeVectorPair,SpecificGeneVectorPair,
			SpecificDiseaseVectorPair),0)
		# align the	specific attribute representations of eight attributes into the attribute 
		# representation with the length of 32*8
		FinalAttributeVectorPair=torch.cat((AveragedSharedAttributeVectorPair,
			AlignSpecificAttributeVectorPair),0)
		# align the shared and specific attribute representations into the final attribute 
		# representation with the length of 64+32*8

		PredictedAdverseInteractionVector=DeepNeuralNetwork_ADDIPredict(FinalAttributeVectorPair)
		# call the loaded deep neural network to output the predicted Adverse interaction vector 
		# of the testing Adverse drug pair (DrugID1, DrugID2)	
		
		AdverseInteractionVector=AdverseInteractionVector.view(1,-1)
		PredictedAdverseInteractionVector=PredictedAdverseInteractionVector.view(1,-1)
		# reshape Tensor vectors AdverseInteractionVector and PredictedAdverseInteractionVector
		# with the length of 258 into a tensor with size of 1*258
		GroundTruthAdverseInteractionOfTestingSet=torch.cat((GroundTruthAdverseInteractionOfTestingSet,
			AdverseInteractionVector),0)
		# store the adverse interaction vector of adverse drug pair (DrugID1,DrugID2) into tensor 
		# GroundTruthAdverseInteractionOfTestingSet
		PredictedAdverseInteractionOfTestingSet=torch.cat((PredictedAdverseInteractionOfTestingSet,
			PredictedAdverseInteractionVector),0)
		# store the predicted adverse interaction vector of adverse drug pair (DrugID1,DrugID2) into tensor 
		# PredictedAdverseInteractionOfTestingSet
		print('Testing Module: Predicting Adverse Interaction Vector of Adverse Drug Pair (%d, %d)' %(DrugID1, DrugID2))

	# print(PredictedAdverseInteractionOfTestingSet.size())
	print('Testing Process Has Finished Completely!!!')
	GroundTruthAdverseInteractionOfTestingSet=GroundTruthAdverseInteractionOfTestingSet[torch.arange(
		GroundTruthAdverseInteractionOfTestingSet.size(0))!=0]
	# remove the first random vector from GroundTruthAdverseInteractionOfTestingSet and maintain the last 2-
	# len(AdverseInteractionTestingList) of the ground-truth Adverse Interaction Vector of testing samples
	PredictedAdverseInteractionOfTestingSet=PredictedAdverseInteractionOfTestingSet[torch.arange(
		PredictedAdverseInteractionOfTestingSet.size(0))!=0]
	# remove the first random vector from PredictedAdverseInteractionOfTestingSet and maintain the last 2-
	# len(AdverseInteractionTestingList) of the predicted Adverse Interaction Vector of testing samples

	GroundTruthAdverseInteractionOfTestingSet=GroundTruthAdverseInteractionOfTestingSet.detach().numpy()
	PredictedAdverseInteractionOfTestingSet=PredictedAdverseInteractionOfTestingSet.detach().numpy()
	# convert tensor GroundTruthAdverseInteractionOfTestingSet and PredictedAdverseInteractionOfTestingSet 
	# into numpy for evaluation
	Specificity,Precision,Recall,F_score,Accuracy,AUC,AUPR=EvaluationModuleForComputingSevenMetrics(
		GroundTruthAdverseInteractionOfTestingSet,PredictedAdverseInteractionOfTestingSet)
	print('Specificity=%f Precision=%f Recall=%f F-score=%f Accuracy=%f AUC=%f AUPR=%f' 
		%(Specificity,Precision,Recall,F_score,Accuracy,AUC,AUPR))

if __name__ == '__main__':


	# load AdverseInteractionDataset by function LoadAdverseInteractionData
	AdverseInteractionDataset=LoadAdverseInteractionData(
		'AdverseInteractionDatasetbyDrugPairAdverseVector.txt')

	# load ReconstructedMolecularStructureMatrix from file ReconstructedMolecularStructure PercentSelectDrug=0.45 PerSelectFeature=0.4 gamma=10.npy
	ReconstructionMolecularStructureMatrix=LoadReconstructionAttributeMatrixInNPYform(
		'ReconstructedMolecularStructure PercentSelectDrug=0.45 PerSelectFeature=0.4 gamma=10.npy')

	# load ReconstructedTargetMatrix from file ReconstructedTarget PercentSelectDrug=0.45 PerSelectFeature=0.45 gamma=0.1.npy
	ReconstructedTargetMatrix=LoadReconstructionAttributeMatrixInNPYform(
		'ReconstructedTarget PercentSelectDrug=0.45 PerSelectFeature=0.45 gamma=0.1.npy')

	# load ReconstructedEnzymeMatrix from file ReconstructedEnzyme PercentSelectDrug=0.45 PerSelectFeature=0.35 gamma=1.npy
	ReconstructedEnzymeMatrix=LoadReconstructionAttributeMatrixInNPYform(
		'ReconstructedEnzyme PercentSelectDrug=0.45 PerSelectFeature=0.35 gamma=1.npy')

	# load ReconstructedPathwayMatrix from file ReconstructedPathway PercentSelectDrug=0.45 PerSelectFeature=0.5 gamma=1.npy
	ReconstructedPathwayMatrix=LoadReconstructionAttributeMatrixInNPYform(
		'ReconstructedPathway PercentSelectDrug=0.45 PerSelectFeature=0.5 gamma=1.npy')

	# load ReconstructedSideEffectMatrix from file ReconstructedSideEffect PercentSelectDrug=0.45 PerSelectFeature=0.25 gamma=1.npy
	ReconstructedSideEffectMatrix=LoadReconstructionAttributeMatrixInNPYform(
		'ReconstructedSideEffect PercentSelectDrug=0.45 PerSelectFeature=0.25 gamma=1.npy')
	# load ReconstructedSideEffectMatrix from file ReconstructedPhenotype PercentSelectDrug=0.45 PerSelectFeature=0.3 gamma=10.npy
	ReconstructedPhenotypeMatrix=LoadReconstructionAttributeMatrixInNPYform(
		'ReconstructedPhenotype PercentSelectDrug=0.45 PerSelectFeature=0.3 gamma=10.npy')

	# load ReconstructedSideEffectMatrix from file ReconstructedGene PercentSelectDrug=0.45 PerSelectFeature=0.25 gamma=1.npy
	ReconstructedGeneMatrix=LoadReconstructionAttributeMatrixInNPYform(
		'ReconstructedGene PercentSelectDrug=0.45 PerSelectFeature=0.25 gamma=1.npy')

	# load ReconstructedSideEffectMatrix from file ReconstructedDisease PercentSelectDrug=0.45 PerSelectFeature=0.5 gamma=0.05.npy
	ReconstructedDiseaseMatrix=LoadReconstructionAttributeMatrixInNPYform(
		'ReconstructedDisease PercentSelectDrug=0.45 PerSelectFeature=0.5 gamma=0.05.npy')

	# call function RandomTrainingSampleAndTestingSampleSeletion to get training samples 
	# and testing samples. Here, the percentage for training is 0.9, the percentage for 
	# testing is 0.1
	Percentage=0.9
	AdverseInteractionTrainingList,AdverseInteractionTestingList=\
		RandomTrainingSampleAndTestingSampleSeletion(AdverseInteractionDataset,Percentage)

	# call function TrainingModuleForSharedAttributeRepresentationLearningWithGeneratorAndDiscriminator
	# to train the generator and discriminator of shared attribute representation learning to get the 
	# shared attribute representations of each training adverse drug pair. The input of this function is the 
	# samples of training adverse interactions of adverse drug pairs, the reconstructed Molecular Structure, 
	# Target, Enzyme, Pathway, Side Effect, Phenotype, Gene, and Disease matrices of drugs. This function  
	# returns the generator and discriminator of shared attribute representation learning
	
	# SharedAttributeRepresentationLearningGen,SharedAttributeRepresentationLearningDis=\
	# 	TrainingModuleForSharedAttributeRepresentationLearningWithGeneratorAndDiscriminator(
	# 		AdverseInteractionTrainingList,ReconstructionMolecularStructureMatrix,
	# 		ReconstructedTargetMatrix,ReconstructedEnzymeMatrix,ReconstructedPathwayMatrix,
	# 		ReconstructedSideEffectMatrix,ReconstructedPhenotypeMatrix,ReconstructedGeneMatrix,
	# 		ReconstructedDiseaseMatrix)


	# call function TrainingModuleForSpecificAttributeRepresentationLearningWithGeneratorAndDiscriminator
	# to train the generator and discriminator of specific attribute representation learning to get the 
	# specific attribute representations of each training adverse drug pair. The input of this function is the 
	# samples of training adverse interactions of adverse drug pairs, the reconstructed  Molecular Structure, 
	# Target, Enzyme, Pathway, Side Effect, Phenotype, Gene, and Disease matrices of drugs. This function  
	# returns the generator and discriminator of specific attribute representation learning
	
	# SpecificAttributeRepresentationLearningGen,SpecificAttributeRepresentationLearningDis=\
	# 	TrainingModuleForSpecificAttributeRepresentationLearningWithGeneratorAndDiscriminator(
	# 		AdverseInteractionTrainingList,ReconstructionMolecularStructureMatrix,
	# 		ReconstructedTargetMatrix,ReconstructedEnzymeMatrix,ReconstructedPathwayMatrix,
	# 		ReconstructedSideEffectMatrix,ReconstructedPhenotypeMatrix,ReconstructedGeneMatrix,
	# 		ReconstructedDiseaseMatrix)


	# call function TrainingModuleForMultiAttributeNeuralNetworkForADDIModeling to 1. compute the 
	# shared attribute representations and specific attribute representations of each training adverse  
	# drug pair in terms of eight attributes and output the final attribute representation of the training 
	# samples by averaging the shared representations and aligning the specific ones; 2. use the 
	# final attribute representations of training adverse drug pair to train the deep neural network 
	# for ADDI modeling. In other words, the trained neural network is to capture the underlying relations
	# between the derived final attribute representation of adverse drug pair and its adverse interactions
	# vector for predicting ADDIs. This function returns the trained deep neural network. 
	
	# DeepNeuralNetwork=TrainingModuleForMultiAttributeNeuralNetworkForADDIModeling(
	# 	AdverseInteractionTrainingList,ReconstructionMolecularStructureMatrix,ReconstructedTargetMatrix,
	# 	ReconstructedEnzymeMatrix,ReconstructedPathwayMatrix,ReconstructedSideEffectMatrix,
	# 	ReconstructedPhenotypeMatrix,ReconstructedGeneMatrix,ReconstructedDiseaseMatrix)


	# call function TestingModuleForPredictingAdverseInteractionInTestingList to predict the adverse 
	# interactions of the testing samples. In particular, for each testing sample, we use the trained 
	# generator of shared attribute representation learning to output its shared representations in 
	# terms of eight attributes and employ the generator of specific attribute representation learning 
	# to derive its specific representations in terms of eight attributes. By averaging the shared attribute 
	# representations and aligning the specific attribute representations, we obtain the final attribute 
	# representation of each testing adverse drug pair and feed it into the trained deep neural network 
	# the derive its predicted adverse Interaction vectors. Finally, we compare the difference between the 
	# predicted adverse interaction vectors and ground-truth adverse interaction vectors of all testing 
	# samples for model evaluation i.e., outputing seven metrics (Specificity,Precision,Recall,F_score,
	# Accuracy,AUC,AUPR). 
	TestingModuleForPredictingAdverseInteractionInTestingList(AdverseInteractionTestingList,
		ReconstructionMolecularStructureMatrix,ReconstructedTargetMatrix,
		ReconstructedEnzymeMatrix,ReconstructedPathwayMatrix,ReconstructedSideEffectMatrix,
		ReconstructedPhenotypeMatrix,ReconstructedGeneMatrix,ReconstructedDiseaseMatrix)


