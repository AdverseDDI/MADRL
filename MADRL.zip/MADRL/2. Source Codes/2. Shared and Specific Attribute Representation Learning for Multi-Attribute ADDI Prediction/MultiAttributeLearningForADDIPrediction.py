from matplotlib import pyplot  
import scipy as sp  
import numpy as np  
import pandas as pd
from matplotlib import pylab  
from sklearn.datasets import load_files   
from sklearn.feature_extraction.text import  CountVectorizer  
from sklearn.feature_extraction.text import  TfidfVectorizer  
from sklearn.naive_bayes import MultinomialNB  
from sklearn.metrics import precision_recall_curve, roc_curve, auc  
from sklearn.metrics import classification_report  
from sklearn.linear_model import LogisticRegression  
import time 
from scipy.linalg.misc import norm
from numpy import *
import os
from sklearn.metrics import roc_auc_score, roc_curve, auc 
from sklearn import metrics
import torch
from torch.autograd import Variable
from torch import nn, optim
from torch.utils.data import DataLoader
from torchvision.utils import save_image
np.set_printoptions(threshold=np.inf) 
torch.set_printoptions(threshold=np.inf) 

# Based on the shared and specific attribute representations of adverse drug pairs, the 
# consensus and complementary effects of eight attributes (i.e., Molecular Structure, 
# Target, Enzyme, Pathway, Side Effect, Phenotype, Gene, and Disease) is captured. in this 
# paper, we design a concatenation strategy to integrate the shared and specific attribute 
# representations of each adverse drug pair. In shared attribute representation learning,
# a four-layer full connection network with the nodes {256, 128, 128, 64} is employed for 
# generating the shared attribute representations, and in specific attribute representation 
# learning, the nodes for the four-layer full connection network is {128, 64, 64, 32}. That  
# indicates the final dimension for shared attribute representations is 64, and the final 
# dimension for specific attribute representations is 32. In the proposed model, we average 
# shared attribute representations of eight attributes and derive the final shared attribute 
# representation of adverse drug pair (d_i, d_j), H_{ij}^{shared}=\frac{1}{M}\sum_{m=1}^M G_{a}^m(H^m_{ij})
# and align specific attribute representations of eight attributes and get the final specific 
# attribute representation of (d_i, d_j), H_{ij}^{specific}=[G_{b}^1(H^m_{ij}), G_{b}^2(H^m_{ij}),
# ... ,G_{b}^M(H^m_{ij})]. 

# the following class is the deep neural network for ADDI modeling. The input of the class is the 
# integration of shared and specific attribute representations of adverse drug pair (d_i, d_j), and the 
# input dimension is 64*8/8+32*8=320, the output dimension is same to the number of adverse interaction
# associated with each adverse drug pair. In our dataset, we use r_{ij}^K to denote the adverse interaction vector
# of adverse drug pair (d_i, d_j), K is the number of adverse interactions. In the following, 
# the integrated shared and specific attribute representation is defined as SharedAndSpecificAttributeVector,
# and its dimension is denoted as SharedAndSpecificAttributeLength, the number of adverse interactions 
# (i.e.,K) is denoted as AdverseInteractionLength. In addition,  the nodes of hidden layers in 
# deep neural network are set as {512, 256, 128, 128, K}.
# Besides, the designed neural network achieves best results with Sigmoid activation function. 
# the dropout rate is set to be 0.5

class DeepNeuralNetworkForADDIModeling(nn.Module):
	def __init__(self, SharedAndSpecificAttributeLength,
		AdverseInteractionLength):
		super(DeepNeuralNetworkForADDIModeling, self).__init__()
	# the design neural network by mapping the integration of shared and specific attribute representations 
	# of adverse drug pair (d_i, d_j) into its adverse interaction vector r_{ij}^K with Sigmoid activation 
	# function and the nodes of hidden layers {512, 256, 128, 128, K}.
		self.DeepNeuralNetwork=nn.Sequential(
			nn.Linear(SharedAndSpecificAttributeLength,512),nn.Dropout(0.5), 
			nn.Sigmoid(),
			nn.Linear(512,256),nn.Dropout(0.5), 
			nn.Sigmoid(),		
			nn.Linear(256,128),nn.Dropout(0.5), 
			nn.Sigmoid(),			
			nn.Linear(128,128),nn.Dropout(0.5), 
			nn.Sigmoid(),			
    		nn.Linear(128,AdverseInteractionLength),nn.Dropout(0.5), 
    		nn.Sigmoid(),
			)		
	# the integrated shared and specific attribute representation is denoted as SharedAndSpecificAttributeVector
	# the forward function is to map the SharedAndSpecificAttributeVector with its length of 
	# SharedAndSpecificAttributeLength into the predicted adverse interaction vector \hat{r}_{ij}^K 
	# here, we denote the predicted adverse interaction vector as PredictedAdverseInteractionVector
	# the forward function returns the predicted adverse interaction vector adverse drug pair (d_i, d_j) 
	# to compute its least-squares loss function with the ground-truth adverse interaction vector of (d_i, d_j)
	def forward(self,SharedAndSpecificAttributeVector):
		PredictedAdverseInteractionVector=self.DeepNeuralNetwork(SharedAndSpecificAttributeVector)
		return PredictedAdverseInteractionVector

# This function is to compute the loss between the predicted Adverse interaction vector and 
# the ground-truth Adverse interaction vector of an Adverse drug pair. Here, we use MSELoss function 
# to calculate the loss. Besides, other loss function (e.g., BCELoss, BCEWithLogitsLoss) can also be used 
# for loss estimation
def LossFunctionOfPredictedAndGroundTruthAdverseInteractionVector(PredictedAdverseInteractionVector,
	AdverseInteractionVector):
	Loss_Function=nn.MSELoss()
	# Initialize the MSELoss by nn.MSELoss()
	Loss=Loss_Function(PredictedAdverseInteractionVector,AdverseInteractionVector)
	# calculate  the loss between the predicted Adverse interaction vector and 
	# the ground-truth Adverse interaction vector of an Adverse drug pair
	return Loss
	# return the Loss value
