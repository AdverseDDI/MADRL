from matplotlib import pyplot  
import scipy as sp  
import numpy as np  
import pandas as pd
import os
from matplotlib import pylab  
from sklearn.datasets import load_files  
# from sklearn.cross_validation import train_test_split  
from sklearn.feature_extraction.text import  CountVectorizer  
from sklearn.feature_extraction.text import  TfidfVectorizer  
from sklearn.naive_bayes import MultinomialNB  
from sklearn.metrics import precision_recall_curve, roc_curve, auc  
from sklearn.metrics import classification_report  
from sklearn.linear_model import LogisticRegression  
import time 
from scipy.linalg.misc import norm
from numpy import *
np.set_printoptions(threshold=np.inf) 
from sklearn.metrics import roc_auc_score, roc_curve, auc 
from sklearn import metrics 
from sklearn.metrics import classification_report, average_precision_score
from sklearn.linear_model import LogisticRegression 
os.environ["CUDA_VISIBLE_DEVICES"] = "0"

# Load DrugStructureMatrix.txt for Representative Drug 
# and Discriminative Feature Selection for Molecular Structure 
def LoadDrugStructureMatrix(DrugStructureMatrixAddress):
	# Input: DrugStructureMatrixAddress is address for file DrugStructureMatrix.txt
	DrugStructureMatrix=[]
	# DrugStructureMatrix is the Molecular Structure matrix of drugs 
	fileIn=open(DrugStructureMatrixAddress)
	# open the File DrugStructureMatrix.txt
	line=fileIn.readline()
	while line:
		lineArr=line.strip().split('\t')
		# Split each line by Tab i.e., \t
		lineSpace=lineArr[1].strip().split()
		# The first entry is the drug Name; The second entry is the Molecular Structure vector for the drug
		# we use the second entry to get the Molecular Structure Matrix
		temp=[]
		for i in lineSpace:
			temp.append(int(i))
			# each element is appended into array temp to get the Molecular Structure vector of each drug
		DrugStructureMatrix.append(temp)
		# append the Molecular Structure of each drug (i.e., temp) to DrugStructureMatrix
		line=fileIn.readline()
	DrugStructureMatrix=np.mat(DrugStructureMatrix)
	# convert list DrugStructureMatrix into matrix DrugStructureMatrix
	return DrugStructureMatrix
	# DrugStructureMatrix corresponds to X^m, m=1, in the paper


# This function is to calculate the row-sum diagonal matrix 
# of similarity matrix SimilarityMatrixS
# i.e., Sum up each row of SimilarityMatrixS as the 
# diagonal element of matrix DiagonalMatrix
def Similarity2DiagonalMatrix(SimilarityMatrixS):
	# Input: similarity matrix calculated by SimilarityMatrixS=(X^m)^T*(X^m), m=1 
	DrugNum,DrugNum=np.shape(SimilarityMatrixS)
	# get the number of row and column of matrix SimilarityMatrixS
	# i.e., the number of drugs
	DiagonalMatrix=np.zeros((DrugNum,DrugNum))
	# initialize the diagonal matrix DiagonalMatrix by an all-zero matrix 
	# the size of DiagonalMatrix is same to SimilarityMatrixS
	for i in range(DrugNum):
		RowSum=0
		for j in range(DrugNum):
			RowSum+=SimilarityMatrixS[i,j]
			# Sum up the i-th row of SimilarityMatrixS as the i-th diagonal element of DiagonalMatrix
		DiagonalMatrix[i,i]=RowSum
	DiagonalMatrix=np.mat(DiagonalMatrix)
	# convert array DiagonalMatrix into matrix DiagonalMatrix
	return DiagonalMatrix
	# DiagonalMatrix is equivalent to matrix D^m,m=1


# This function is to return a diagonal matrix with its entries
# being the reciprocal of the L_{2}-norm of each row 
# i.e., 1/(2*||x||_{2}+small vaule)
def Norm2_1DiagMatrix(TempMatrix):
	RowNum, Column=np.shape(TempMatrix)
	# get the row and column of input matrix TempMatrix
	DiagMatrix=np.mat(np.zeros((RowNum,RowNum)))
	# initialize the return diagonal matrix, the size of DiagMatrix corresponds to 
	# the number of row in input matrix TempMatrix
	for i in range(RowNum):
		DiagMatrix[i,i]=1/(2*np.linalg.norm(TempMatrix[i,:])+0.00001)
	# compute each diagonal entry, we set small vaule=0.00001
	# np.linalg.norm calculates the L_{2}-norm of the i-th row of matrix TempMatrix
	return DiagMatrix

# This function is to compute the L_{2,1} norm of matrix
# which is to calculate the sum of L_{2} norm of each row 
# of a matrix
def L_2_1_normMatrix(TempMatrix):
	# input TempMatrix: compute the L_{2,1} norm of TempMatrix
	Row, Column=np.shape(TempMatrix)
	# get the row and column of input matrix TempMatrix
	L_2_1=0
	# initialize L_2_1 = 0
	for i in range(Row):
		L_2_1=L_2_1+np.linalg.norm(TempMatrix[i,:])
		# compute the L_2 norm of the i-th row of TempMatrix
	return L_2_1

# This function is used to select representative drugs and Discriminative feature 
# for Molecular Structure matrix of drugs. To be specific, this function is to optimize 
# matrix W^m to get the selection indicators of discriminative Molecular Structure 
# and representative drugs. W^m is constrained by (1) the number of non-zero row is \bar{C}_m,
# i.e., the number of selected Molecular Structure is \bar{C}_m, ||W^m||_{2,0}=\bar{C}_m, and 
# (2) the number of non-zero column is \bar{N},i,e,. the number of selected drugs is \bar{C}_m,
# ||(W^m)^T||_{2,0}=\bar{N}. With the incorporated of graph manifold regularization, we use 
# ADMM for optimization with the auxiliary matrices Y^m, and Z^m, where W^m = Y^m and (W^m)^T=Z_m, m=1

# in the following function, eigenvalue decomposition is used to factorize matrix A^m and 
# X^m*(X^m)^T so as to derive the closed-form solution of W^m. Auxiliary matrices Y^m, and Z^m
# can be updated by first calculate the the partial derivatives w.r.t.  Y^m, and Z^m, and then 
# setting them to be zeros. Lagrange multipliers Lambda_m, Tau_m are updated at last. Meanwhile, we 
# also prove that the objective function is non-increasing with the solution for W^m, Y^m, and Z^m
# The detailed derivation procedure for getting the closed-form solutions for W^m, Y^m, and Z^m
# can be found in Appendix A of Supplementary Material. And the detailed convergence proofs for matrices 
# Y^m, and Z^m are presented in Appendix B of Supplementary Material. 
def SelectRepresentativeDrugsFeatureforMolecularStructure(DrugStructureMatrix,AttributeName):
# Input: DrugTargetMatrix the Target matrix of drugs, i.e., X^m, m=1
# AttributeName is the attribute name, here, AttributeName="MolecularStructure"
# in particular, DrugStructureMatrix corresponds to X^m, m=1, in the manuscript

	DrugNum,FeatureNum=np.shape(DrugStructureMatrix)
	# get the size of DrugStructureMatrix, i.e., 
	# the number of row (drug number) and column (substructure number) for DrugStructureMatrix
	
	SimilarityMatrixS=DrugStructureMatrix*DrugStructureMatrix.transpose()
	# calculate the similarity matrix by DrugStructureMatrix^T*DrugStructureMatrix
	# i.e., SimilarityMatrixS=(X^m)^T*(X^m), m=1 
	# same to matrix S^m shown in manuscript

	DiagonalMatrixD=Similarity2DiagonalMatrix(SimilarityMatrixS)
	# calculate matrix D^m, D^m is a diagonal matrix with the i-th diagonal element 
	# being the sum of the i-th row for SimilarityMatrixS 
	# DiagonalMatrixD corresponds to matrix D^m

	LaplacianMatrixL=DiagonalMatrixD-SimilarityMatrixS
	# compute the Laplacian matrix LaplacianMatrixL 
	# i.e., L^m=D^m-S^m

	alpha_m=[0.0001,0.001,0.01,0.05,0.1,0.5,1,5,10,100,500,1000,5000,10000]
	# alpha_m controls l_{2,1} norm of matrix Y^m, i.e., ||Y^m||_{2,1}
	# W^m = Y^m
	beta_m=[0.0001,0.001,0.01,0.05,0.1,0.5,1,5,10,100,500,1000,5000,10000]
	# alpha_m controls l_{2,1} norm of matrix Z^m, i.e., ||Z^m||_{2,1}
	# (W^m)^T = Z^m
	lambda_m=[0.0001,0.001,0.01,0.05,0.1,0.5,1,5,10,100,500,1000,5000,10000]
	# lambda_m controls the Graph Manifold Regularization 
	# tr[(X^m*W^m*X^m)^T*L^m*(X^m*W^m*X^m)]

	# NOTICE!!!
	# For Molecular Structure, MADRL outputs the best results 
	# when alpha=100, beta=10, and lambda=5
	# For further discussion, we can use the above three parameter ranges 
	# to analyze the effects of alpha, beta, and lambda on model performance
	# In the following, we set alpha=100, beta=10, and lambda=5 to estimate 
	# matrix W^m for the downstream Molecular structure matrix reconstruction
	alpha_m=[100]
	beta_m=[10]
	lambda_m=[5]

	MaxIter=100
	# the maximum iterations


	Theta_2_m, Q_m = np.linalg.eig(SimilarityMatrixS)
	# Using eigenvalue decomposition for decomposing matrix SimilarityMatrixS
	# Theta_2_m is the vector with its entries being the eigenvalues of SimilarityMatrixS
	# Q_m is the matrix constructed by the eigenvectors of SimilarityMatrixS

	Theta_2_m=np.mat(np.diag(Theta_2_m))
	# convert vector Theta_2_m into a diagonal matrix

	for alpha in alpha_m:
		for beta in beta_m:
			for lambdaa in lambda_m:
				Rou1=Rou2=0.000001 
				Max_Rou=1000000
				tau=1.1 # tau is used to update Rou1 and Rou2
				threshold=0.00001
				# set the parameters Rou1,Rou2, tua, and threshold
				
				# initialize matrices W^m, Y^m, and Z^m by all-zero matrices  
				W_m=np.mat(np.zeros((FeatureNum,DrugNum)))
				Y_m=np.mat(np.zeros((FeatureNum,DrugNum)))
				# Y^m is auxiliary matrix of W^m and set W^m=Y_m
				Z_m=np.mat(np.zeros((DrugNum,FeatureNum)))
				# Z^m is auxiliary matrix of (W^m)^T and set (W^m)^T=Z_m
				
				Lambda_m=np.mat(np.zeros((FeatureNum,DrugNum)))
				# the size of Lambda^m is same to W_m and Y_m 
				Tau_m=np.mat(np.zeros((DrugNum,FeatureNum)))
				# the size of Tau_m is same to Z_m
				# initialize Lagrange multipliers Lambda^m and Tau_m by all-zero matrices

				Delta_threshold=0.00001
				W_m_last=np.mat(np.zeros((FeatureNum,DrugNum)))
				# record the value of matrix W_m in the last iteration

				A_m=(2*DrugStructureMatrix.transpose()*DrugStructureMatrix+
					2*lambdaa*DrugStructureMatrix.transpose()*LaplacianMatrixL*DrugStructureMatrix)
				# calculate matrix A^m=2*(X^m)^T*X^m+2*lambdaa^m(X^m)^T*L^m*X^m, m=1

				# eig for A_m
				Theta_1_m, P_m= np.linalg.eig(A_m)
				# Using eigenvalue decomposition for decomposing matrix A_m
				# Theta_1_m is the vector with its entries being the eigenvalues of A_m
				# P_m is the matrix constructed by the eigenvectors of A_m

				Theta_1_m=np.mat(np.diag(Theta_1_m))
				# convert vector Theta_1_m into a diagonal matrix

				# update matrix W^m in the following
				for Iter in range(MaxIter):
					print('Iteration Number:%d' %(Iter+1))
					# output iteration number for mark!

					# calculate B_m
					temp1_B_m=2*DrugStructureMatrix.transpose()*DrugStructureMatrix*DrugStructureMatrix.transpose()
					# the first term for matrix B^m is 2*(X^m)^T*X^m*(X^m)^T
					temp2_B_m=Rou1*(Y_m-Lambda_m/Rou1)
					# the second term for matrix B^m is rho_1*(Y^m-Lambda_m/rho_1)
					temp3_B_m=Rou2*(Z_m-Tau_m/Rou2).transpose()
					# the third term for matrix B^m is rho_2*(Z^m-Tau_m/rho_2)
					B_m=temp1_B_m+temp2_B_m+temp3_B_m
					# sum up temp1_B_m,temp2_B_m and temp2_B_m to get B_m
					F_m=P_m.transpose()*B_m*Q_m
					# compute the numerator of matrix C^m
					C_m=np.mat(np.zeros((FeatureNum,DrugNum)))
					# initialize matrix C^m by an all-zero matrix
					# the size of C^m is the same with W^m

					for i in range(FeatureNum):
						for j in range(DrugNum):
							C_m[i,j]=F_m[i,j]/(Theta_1_m[i,i]*Theta_2_m[j,j]+Rou1+Rou2)
					# update matrix C^m in an element-wise manner

					W_m=P_m*C_m*Q_m.transpose()
					# Update W_m by P^M*C^m*(Q^m)^T

					## Update Y_m in the following:
					D_Y_m=Norm2_1DiagMatrix(Y_m)
					# get the reciprocal of the L_{2}-norm of each row to obtain matrix D^M_Y
					I_FeatureNum=np.mat(np.identity(FeatureNum))
					# get an identity matrix with the size of FeatureNum*FeatureNum
					temp4_Y_m=(alpha*D_Y_m+Rou1*I_FeatureNum)
					# compute (alpha^m*D_Y^m+Rou1*I_FeatureNum), i.e., the first term to be inverted
					temp4_Y_m=np.linalg.inv(temp4_Y_m)
					# calculate the invert of temp4_Y_m
					Y_m=temp4_Y_m*(Rou1*W_m+Lambda_m)
					# update matrix Y^m

					## Update matrix Z_m
					D_Z_m=Norm2_1DiagMatrix(Z_m)
					# get the reciprocal of the L_{2}-norm of each row to obtain matrix D^M_Z
					I_DrugNum=np.mat(np.identity(DrugNum))
					# get an identity matrix with the size of DrugNum*DrugNum
					temp5_Z_m=(beta*D_Z_m+Rou2*I_DrugNum)
					# compute (beta^m*D_Z^m+Rou2*I_DrugNum), i.e., the first term to be inverted
					temp5_Z_m=np.linalg.inv(temp5_Z_m)
					# calculate the invert of temp5_Z_m
					Z_m=temp5_Z_m*(Rou2*W_m.transpose()+Tau_m)
					# update matrix Z^m
					
					Lambda_m=Lambda_m+Rou1*(W_m-Y_m)
					# Update Lambda_m
					Tau_m=Tau_m+Rou2*(W_m.transpose()-Z_m)
					# Update Tau_m

					Rou1=min(tau*Rou1,Max_Rou)
					Rou2=min(tau*Rou2,Max_Rou)
					# Update Rou1 and Rou2 by min(tau*Rou1,Max_Rou) and min(tau*Rou2,Max_Rou)

					# termination condition for the iteration: 
					Delta_Y_m=W_m-Y_m
					Delta_Y_m=np.linalg.norm(Delta_Y_m, ord=np.inf)
					# calculate the infinite norm of W_m-Y_m
					# the entry with the maximum absolute value in a matrix denote its infinite norm 
					Delta_Z_m=W_m.transpose()-Z_m
					Delta_Z_m=np.linalg.norm(Delta_Z_m, ord=np.inf)
					# calculate the infinite norm of (W_m)^T-Y_m

					if Delta_Z_m<threshold and Delta_Y_m<threshold:
						break
					# termination condition 1: the infinite norms of W_m-Y_m 
					# and W_m.transpose()-Z_m are less than threshold
					# i.e., the difference between W_m and its two auxiliary matrices less than threshold


					# termination condition 2: the absolute objective function difference 
					# between two iteration is less than Delta_threshold=0.00001
					DrugStructureMatrix_Cal=DrugStructureMatrix*W_m*DrugStructureMatrix
					# compute matrix X^m*W^m*X^m used to estimate the loss between 
					# two adjacent iterations
					Delta=DrugStructureMatrix-DrugStructureMatrix_Cal
					# compute the loss between X^m-X^m*W^m*X^m
					Delta=np.linalg.norm(Delta)
					# compute Frobenius norm of the loss
					Delta=Delta+alpha*L_2_1_normMatrix(W_m)+beta*L_2_1_normMatrix(W_m.transpose())
					# sum up the L_{2,1}-norm of matrix W^m and W^m.transpose()
					Delta=Delta+lambdaa*np.trace(DrugStructureMatrix_Cal.transpose()*LaplacianMatrixL
						*DrugStructureMatrix_Cal)
					# sum up lambdaa*tr{(X^m*W^m*X^m)^T*L^m*(X^m*W^m*X^m)} to get the objective function 
					# in this iteration

					DrugStructureMatrix_Cal_last=DrugStructureMatrix*W_m_last*DrugStructureMatrix
					# compute matrix X^m*W^m*X^m for the last iteration 
					Delta_last=DrugStructureMatrix-DrugStructureMatrix_Cal_last
					# compute the loss between X^m-X^m*W^m*X^m for the last iteration
					Delta_last=np.linalg.norm(Delta_last)
					# compute Frobenius norm of the loss
					Delta_last=Delta_last+alpha*L_2_1_normMatrix(W_m)+beta*L_2_1_normMatrix(W_m.transpose())
					# sum up the L_{2,1}-norm of matrix W_m and W_m.transpose() for the last iteration
					Delta_last=Delta_last+lambdaa*np.trace(DrugStructureMatrix_Cal_last.transpose()*LaplacianMatrixL
						*DrugStructureMatrix_Cal_last)
					# sum up lambdaa*tr{(X^m*W^m_last*X^m)^T*L^m*(X^m*W^m_last*X^m)} to get the objective function 
					# in the last iteration

					Adjacent_Loss=abs(Delta-Delta_last)/Delta
					# compute the loss between two adjacent iterations 
					print('Absolute Loss=%.10f' %(Adjacent_Loss))
					if Adjacent_Loss>=Delta_threshold:  # the loss is higher than Delta_threshold=0.00001
						W_m_last=W_m  # record the current W^m
					elif Adjacent_Loss<Delta_threshold: # the loss is less then Delta_threshold 
						break # break the Loops

				np.save(AttributeName+'_W^m'+' alpha='+str(alpha)+' beta='+str(beta)+
					' lambda='+str(lambdaa),W_m)
				# save matrix W_m, this file is coded by numpy that can be read by command np.load 
				# but open with messy code
				np.savetxt(AttributeName+'_W^m'+' alpha='+str(alpha)+' beta='+str(beta)+
					' lambda='+str(lambdaa)+'.txt',W_m)
				# to directly show matrix W_m, we use np.savetxt to output the matrix W_m. This 
				# file can be opened with showing  the value of each entry in W_m

				# Output the W^m for Molecular structure
				# so as to get the selected representative drugs 
				# and discriminative features (molecular substructure)

if __name__ == '__main__':

	DrugStructureMatrixAddress='DrugStructureMatrix.txt'
	# get the file name of DrugStructureMatrix

	DrugStructureMatrix=LoadDrugStructureMatrix(DrugStructureMatrixAddress)
	# call function LoadDrugStructureMatrix to get the Molecular Structure matrix of drugs

	SelectRepresentativeDrugsFeatureforMolecularStructure(DrugStructureMatrix,'MolecularStructure')
	# call function SelectRepresentativeDrugsFeatureforMolecularStructure
	# to select representative drugs and Discriminative feature for 
	# Molecular Structure matrix of drugs



