from matplotlib import pyplot  
import scipy as sp  
import numpy as np  
import pandas as pd
from matplotlib import pylab  
from sklearn.datasets import load_files   
from sklearn.feature_extraction.text import  CountVectorizer  
from sklearn.feature_extraction.text import  TfidfVectorizer  
from sklearn.naive_bayes import MultinomialNB  
from sklearn.metrics import precision_recall_curve, roc_curve, auc  
from sklearn.metrics import classification_report  
from sklearn.linear_model import LogisticRegression  
import time 
from scipy.linalg.misc import norm
from numpy import *
import os
np.set_printoptions(threshold=np.inf) 
from sklearn.metrics import roc_auc_score, roc_curve, auc 
from sklearn import metrics 
import time
from sklearn.metrics import classification_report, average_precision_score
from sklearn.linear_model import LogisticRegression 
import torch
from torch.autograd import Variable
from torch import nn, optim
from torch.utils.data import DataLoader
from torchvision.utils import save_image
import os
import pickle
os.environ["CUDA_VISIBLE_DEVICES"] = "0"

# This function is to Load DrugTargetMatrix.txt for Representative Drug 
# and Discriminative Feature Selection for Target 
def LoadDrugTargetMatrix(DrugTargetMatrixAddress):
	# Input: DrugTargetMatrixAddress is address for file DrugTargetMatrix.txt
	DrugTargetMatrix=[]
	fileIn=open(DrugTargetMatrixAddress)
	# open the File DrugTargetMatrix.txt
	line=fileIn.readline()
	while line:
		lineArr=line.strip().split('\t')
		# Split each line by Tab i.e., \t
		lineSpace=lineArr[1].strip().split()
		# The first entry is the drug Name; The second entry is  
		# the Target vector for the drug
		# we use the second entry to get the Target Matrix
		temp=[]
		for i in lineSpace:
			temp.append(int(i))
			# each element is appended into array temp to get the Target vector of each drug
		DrugTargetMatrix.append(temp)
		# append the Target of each drug (i.e., temp) to DrugTargetMatrix
		line=fileIn.readline()
	DrugTargetMatrix=np.mat(DrugTargetMatrix)
	# convert list DrugTargetMatrix into matrix DrugTargetMatrix
	return DrugTargetMatrix
	# DrugTargetMatrix corresponds to X^m, m=2, in the paper

# This function is to load matrix W^m output by SelectRepresentativeDrugDiscriminativeTarget.py
# under the parameter combination of alpha,beta,lambda 
def LoadW_mMatrixDerivedByDrugAndTargetSelection(AttributeName,alpha,beta,lambdaa):
	# load W^m matrix from (AttributeName+'_W^m'+' alpha='+str(alpha)+' 
	# beta='+str(beta)+lambda='+str(lambdaa)+'.npy'
	W_m=np.load(AttributeName+'_W^m'+' alpha='+str(alpha)+' beta='+str(beta)
		+' lambda='+str(lambdaa)+'.npy')
	# Target_W^m alpha=10 beta=10 lambda=1000.npy records matrix W^m that can be read by np.load
	# Target_W^m alpha=10 beta=10 lambda=1000.txt records the value of each entry in W^m
	return W_m


# This class is to record the row (column) number of a matrix and the sum 
# of entris in the corresponding row and column. Given a matrix W_m, 
# the sum of entries for the i-th row is recorded by the object (i, sum(W_m[i,]))
# the sum of entries for the j-th column is recorded by the object (j, sum(W_m[,j]))
# For matrix W_m, we use a list WeightMatrixRowVector to record (i, sum(W_m[i,])), i=1, ... , RowNumber
# and a list WeightMatrixColumnVector to record (j, sum(W_m[,j])),  j=1, ... , ColumnNumber
# based on this class, we use quicksort function to sort WeightMatrixRowVector by sum(W_m[i,]
# to get the rows with the highest Sum of row entries, and sort WeightMatrixColumnVector by sum(W_m[,j]
# to get the columns with the highest Sum of column entries. Finally, the rows with the top
# SelectFeatureNum Sum of row entries in matrix W_m are considered as discriminative Target, 
# and the columns with the top SelectDrugNum Sum of column entries in matrix W_m 
# are considered as representative drugs 
class IndexValues:
    def __init__(self,Index,Value):
        self.Index = Index
        self.Value = Value


# This function is to return a diagonal matrix with its entries
# being the reciprocal of the L_{2}-norm of each row 
# i.e., 1/(2*||x||_{2}+small vaule)
def Norm2_1DiagMatrix(TempMatrix):
	RowNum, Column=np.shape(TempMatrix)
	# get the row and column of input matrix TempMatrix
	DiagMatrix=np.mat(np.zeros((RowNum,RowNum)))
	# initialize the return diagonal matrix, the size of DiagMatrix corresponds to 
	# the number of row in input matrix TempMatrix
	for i in range(RowNum):
		DiagMatrix[i,i]=1/(2*np.linalg.norm(TempMatrix[i,:])+0.00001)
	# compute each diagonal entry, we set small vaule=0.00001
	# np.linalg.norm calculates the L_{2}-norm of the i-th row of matrix TempMatrix
	return DiagMatrix

# This function is to compute the L_{2,1} norm of matrix
def L_2_1_normMatrix(TempMatrix):
	# input TempMatrix: compute the L_{2,1} norm of TempMatrix
	Row, Column=np.shape(TempMatrix)
	# get the row and column of input matrix TempMatrix
	L_2_1=0
	# initialize L_2_1 = 0
	for i in range(Row):
		L_2_1=L_2_1+np.linalg.norm(TempMatrix[i,:])
		# compute the L_2 norm of the i-th row of TempMatrix
	return L_2_1



# This function is to return a left matrix and a right so as to get 
# a low-dimensional representation of the original Target matrix \tilde{X}^m of drugs,m=2
# in which the left matrix is diag(a^m), and the right matrix is diag(b^m)
# binary vector a^m\in{0,1} is selection indicators of drugs, a^m_{i}=1 indicate 
# the i-th is selected as representative drugs, otherwise a^m_{i}=0
# Likewise, binary vector b^m\in{0,1} is selection indicators of Target, 
# b^m_{i}=1 indicate the i-th is Target selected as 
# discriminative features, otherwise b^m_{i}=0
# vector a^m can be computed by first adding up the values over the corresponding columns
# of matrix W^m i.e., a^m=sum_{col}(W^m) and then setting the top \bar{N} largest entries 
# in a^m to be 1s and the rest (N-\bar{N}) values to be 0s, indicating the corresponding 
# drugs (indexes) with a^m_{i}=1 are selected as representative drugs
# vector b^m can be computed by first adding up the values over the corresponding rows
# of matrix W^m i.e., b^m=sum_{row}(W^m) and then setting the top \bar{C}_m largest entries 
# in b^m to be 1s and the rest (C_m-\bar{C}_m) values to be 0s, indicating the corresponding 
# features (indexes) with b^m_{i}=1 are selected as discriminative features
def GetSelectionIndicatorsForDrugFeature(W_m,
	PercentageSelectedDrug,PercentageSelectedFeature):
# Input: matrix W_m is derived by SelectRepresentativeDrugDiscriminativeTarget.py
# PercentageSelectedDrug is the percentage of drugs selected as representative drugs 
# PercentageSelectedFeature is the percentage of features selected as discriminative features

	FeatureNum,DrugNum=np.shape(W_m)
	# get the size of W_m, row=number of features, column=number of drugs

	SelectDrugNum=(int)(DrugNum*PercentageSelectedDrug)
	# get the number of drugs to be selected, i.e., the Cut-off integer of PercentageSelectedDrug*DrugNum
	SelectFeatureNum=(int)(FeatureNum*PercentageSelectedFeature)
	# get the number of Target to be selected, 
	# i.e., the Cut-off integer of FeatureNum*PercentageSelectedFeature
	
	WeightMatrixRowVector=[]
	# WeightMatrixRowVector is a list recording the item of class 
	# IndexValues(Index, Value) of matrix W_m. 
	# in which the first entry Index is the row number and the second 
	# entry is the sum of the Index-th row of matrix W_m. 
	# WeightMatrixRowVector is used to sort the rows of W_m by the value of 
	# the sum of each row, i.e,. sum_{row}(W^m) as selection indicators of Target

	WeightMatrixColumnVector=[]
	# WeightMatrixRowVector is a list recording the item of class 
	# IndexValues(Index, Value) of matrix W_m. 
	# in which the first entry Index is the column number and the second 
	# entry is the sum of the Index-th column of matrix W_m. 
	# WeightMatrixColumnVector is used to sort the columns of W_m by the value of 
	# sum of each column, i.e., sum_{col}(W^m) as selection indicators of drugs
	for i in range(FeatureNum):
		# traverse the row of matrix W^m, row=FeatureNum
		RowSum=0
		# Initialize the sum of each row by 0
		for j in range(DrugNum):
			RowSum+=W_m[i,j]
		# sum up the values of the i-th row elements
		Temp=IndexValues(i,RowSum)
		# Initialize the class variable Temp by IndexValues(i, RowSum)
		# i is the row number, RowSum is the sum of the i-th row, i.e., sum_{row}(W^m_{i})
		WeightMatrixRowVector.append(Temp)
		# append Temp into WeightMatrixRowVector, i.e., 
		# append (i,sum_{row}(W^m_{i})) into WeightMatrixRowVector
	WeightMatrixRowVector.sort(key= lambda x:x.Value)
	# Totally, there are C_m (FeatureNum) rows in W^m, and WeightMatrixRowVector records the row number 
	# and the sum of each row. This operation is to sort the element (Index, Value) (i.e., (i, RowSum)) 
	# in WeightMatrixRowVector by Value (RowSum) in an ascending order


	for i in range(DrugNum):
		# traverse the column of matrix W^m, column=DrugNum
		ColumnSum=0
		# Initialize the sum of each column by 0
		for j in range(FeatureNum):
			ColumnSum+=W_m[j,i]
			# sum up the values of the i-th column elements
		Temp=IndexValues(i,ColumnSum)
		# Initialize the class variable Temp by IndexValues(i, ColumnSum)
		# i is the column number, ColumnSum is the sum of the i-th column, 
		# i.e., sum_{col}(W^m_{.i}) 
		WeightMatrixColumnVector.append(Temp)
		# append Temp into WeightMatrixColumnVector, i.e., 
		# append (i,sum_{col}(W^m_{.i})) into WeightMatrixColumnVector
	WeightMatrixColumnVector.sort(key= lambda x:x.Value)
	# Likewise, there are N (DrugNum) columns in W^m, and WeightMatrixColumnVector records the column number 
	# and the sum of each column. This operation is to sort the element (Index, Value) (i.e., (i, ColumnSum)) 
	# in WeightMatrixColumnVector by Value (ColumnSum) in an ascending order

	b_m=np.zeros(FeatureNum)
	# b_m is the selection indicators of Target with the size of FeatureNum
	a_m=np.zeros(DrugNum)
	# a_m is the selection indicators of drugs with the size of DrugNum

	for i in range(SelectFeatureNum):
		# WeightMatrixRowVector is sorted in an ascending order by the sum of the each row 
		# traverse WeightMatrixRowVector and the indexes with the top SelectFeatureNum sum of entries in row
		# are selected the discriminative features
		index=WeightMatrixRowVector[FeatureNum-1-i].Index
		# get the index number of the (FeatureNum-1-i)-th RowSum
		value=WeightMatrixRowVector[FeatureNum-1-i].Value
		# get the (FeatureNum-1-i)-th RowSum
		b_m[index]=1.0
		# set the corresponding index in b_m to be 1, indicating that the 
		# index-th Target is selected as the discriminative features

	for i in range(SelectDrugNum):
		# WeightMatrixColumnVector is sorted in an ascending order by the sum of the each column 
		# traverse WeightMatrixColumnVector and the indexes with the top SelectDrugNum sum of entries in column
		# are selected the representative drugs
		index=WeightMatrixColumnVector[DrugNum-1-i].Index
		# get the index number of the (DrugNum-1-i)-th ColumnSum
		value=WeightMatrixColumnVector[DrugNum-1-i].Value
		# get the (DrugNum-1-i)-th ColumnSum
		a_m[index]=1.0
		# set the corresponding index in a_m to be 1, indicating that the 
		# index-th drug is selected as the representative drugs

	Diagonal_b_m=np.mat(np.diag(b_m))
	# convert binary vector b_m into diagonal matrix as 
	# the right matrix for discriminative Target selection

	Diagonal_a_m=np.mat(np.diag(a_m))
	# convert binary vector a_m into diagonal matrix as 
	# the left matrix for representative drug selection
	return Diagonal_a_m, Diagonal_b_m
	# return the selection indicators matrix Diagonal_a_m and Diagonal_b_m
	# for representative drugs and discriminative features (Target), respectively


# This function is to employ Singular Value Decomposition (SVD) to factorize
# a real symmetric matrix TempMatrix, and then use the singular vectors related 
# to the top N_Top largest singular values to reconstruct TempMatrix. 
# Based on SVD, TempMatrix can be factorized as a leftmatrix, a diagonal matrix DIAG with its singular
# being the diagonal elements, and a rightmatrix, i.e., TempMatrix=leftmatrix*DIAG*rightmatrix.
# we can use the N_Top largest singular values to approximate TempMatrix, and DIAG can be written 
# by the N_Top largest singular values on diagonal, leftmatrix can be written by the singular vectors
# corresponding to N_Top largest singular values, i.e., selecting the first N_Top columns of leftmatrix,
# rightmatrix can be written by the singular vectors corresponding to N_Top largest singular values, 
# i.e., selecting the first N_Top rows of rightmatrix,
# Due to TempMatrix is symmetric, leftmatrix=(rightmatrix)^T. Since TempMatrix is aimed to be 
# factorized as TempMatrix=F^m*(F^m)^T, we decompose diagonal matrix DIAG as DIAG=sqrt(DIAG)*sqrt(DIAG)
# and thus, F^m=leftmatrix*sqrt(DIAG) and (F^m)^T=sqrt(DIAG)*rightmatrix
def SingularValueDecompositionWithTopSingularForReconstruction(TempMatrix,N_Top):
# Input TempMatrix is the matrix to be factorized, N_Top is the number of singulars
# for the reconstruction of TempMatrix based on Singular Value Decomposition
	Leftmatrix, DIAG, RightMatrix=np.linalg.svd(TempMatrix)
	# using SVD to factorize TempMatrix, since TempMatrix is symmetric,
	# we have Leftmatrix=(RightMatrix)^T, DIAG is the vector of its singular values 
	# in a descending order, Leftmatrix and RightMatrix are composed by the singular vectors 
	# of TempMatrix on the columns and rows of Leftmatrix and RightMatrix, respectively
	Leftmatrix=np.mat(Leftmatrix)
	RightMatrix=np.mat(RightMatrix)
	# convert arraies Leftmatrix and RightMatrix into matrices 
	DIAG_N_Top=np.mat(np.diag(DIAG[0:N_Top]))
	# select the first N_Top singular vectors to construct a diagonal matrix
	DIAG_N_Top=sqrt(DIAG_N_Top)
	# sqrt the elements of DIAG_N_Top to merge DIAG_N_Top into Leftmatrix and RightMatrix
	Leftmatrix_N_Top=Leftmatrix[:,0:N_Top]
	# select the first N_Top columns from Leftmatrix, i.e., singular vectors corresponding to 
	# the N_Top singular values
	Rightmatrix_N_Top=RightMatrix[0:N_Top,:]
	# select the first N_Top rows from RightMatrix, i.e., singular vectors corresponding to 
	# the N_Top singular values 
	F_m=Leftmatrix_N_Top*DIAG_N_Top
	# using the first N_Top columns from Leftmatrix to get Leftmatrix_N_Top and right multiply 
	# DIAG_N_Top
	# F_m can also be derived by using the first N_Top rows from RightMatrix and left multiply
	# DIAG_N_Top, i.e., F^m=(DIAG_N_Top*Rightmatrix_N_Top).transpose()
	return F_m
	# return F^m for updating matrix Fai_m

# This function is to use the derive matrix W^m to reconstruct the original 
# Target matrix of drugs 
def TargetMatrixReconstruction(DrugTargetMatrix,W_m,AttributeName):
# input: original Target matrix DrugTargetMatrix, i.e., X^m, m=2
# W_m is matrix W^m provided by SelectRepresentativeDrugDiscriminativeTarget.py
# AttributeName="Target"
	DrugNum, FeatureNum=np.shape(DrugTargetMatrix)
	# get the row and column of W_m, row=number of drugs, column=number of Target

	PercentageSelectedDrugSet=[0.05,0.10,0.15,0.20,0.25,0.30,0.35,0.40,0.45,0.50,0.55,
		0.60,0.65,0.70,0.75,0.80]
	# the percentage of the selected representative drugs \bar{N} for constructing
	# the Target matrix of drugs X^m, m=2
	PercentageSelectedFeatureSet=[0.05,0.10,0.15,0.20,0.25,0.30,0.35,0.40,0.45,0.50,0.55,
		0.60,0.65,0.70,0.75,0.80]
	# the percentage of the selected discriminative features \bar{C}_m for constructing
	# the Target matrix of drug X^m, m=2
	gamma_m=[0.0001,0.001,0.01,0.05,0.1,0.5,1,5,10,100,500,1000,5000,10000]
	# gamma_m controls the L_{2,1} norm of matrix (Φ^m)^T, i.e., ||(Φ^m)^T||_{2,1}, m=2

	# NOTICE!!!
	# For Target, MADRL outputs the best results 
	# when PercentageSelectedDrug=0.45, PercentageSelectedFeature=0.45, and gamma=0.1
	# For further discussion, we can use the above three parameter ranges 
	# to analyze the effects of PercentageSelectedDrug, PercentageSelectedFeature, 
	# and gamma_m on model performance
	# In the following, we set PercentageSelectedDrug=0.45, PercentageSelectedFeature=0.45, 
	# and gamma=0.1 for the reconstruction of Target matrix of drugs 
	PercentageSelectedDrugSet=[0.45]
	PercentageSelectedFeatureSet=[0.45]
	gamma_m=[0.1]

	MaxIter=100
	# the maximum iterations

	threshold=0.00001
	# threshold the difference of Fai_m between two adjacent iterations with infinite norm
	Delta_threshold=0.00001

	for PercentageSelectedDrug in PercentageSelectedDrugSet:
		for PercentageSelectedFeature in PercentageSelectedFeatureSet:
			for gamma in gamma_m:
				# traverse PercentageSelectedDrugSet, PercentageSelectedFeatureSet, and gamma_m
				# here we set PercentageSelectedDrug=0.45, PercentageSelectedFeature=0.45,and gamma=0.1 

				Fai_m=np.mat(np.zeros((DrugNum,DrugNum)))
				# Initialize matrix Fai^m by an all-zero matrix, the size of Fai_m is DrugNum*DrugNum
				Fai_m_last=np.mat(np.zeros((DrugNum,DrugNum)))
				# record matrix Fai_m in the last iteration by an all-zero matrix

				LeftMatrix,RightMatrix=GetSelectionIndicatorsForDrugFeature(
					W_m,PercentageSelectedDrug,PercentageSelectedFeature)
				# call function GetSelectionIndicatorsForDrugFeature to get the left matrix 
				# and the right matrix, where left matrix is converted from selection indicators a_m 
				# for representative drug selection, and right matrix is transformed from selection 
				# indicator b_m for discriminative Target selection
				
				# Thus, the low-dimensional representation of X^m is 
				# \tilde{x}^m=diag(a^m)*X^m*diag(b^m), i.e., LeftMatrix*X^m*RightMatrix
				DrugTargetMatrix_Reduced=LeftMatrix*DrugTargetMatrix*RightMatrix
				# the reduced Target matrix of drugs can be used to reconstruct its original Target space 
				# and get the reconstructed Target representations of drugs and adverse drug pairs

				SingularNumber=(int)(0.1*DrugNum) 
				# set the number of Singulars for singular value decomposition (SVD)
				# of matrix DrugTargetMatrix_Reduced*DrugTargetMatrix_Reduced.transpose()
				# we empirically set as SingularNumber=10%*DrugNum

				# Training process for optimizing matrix Fai_m
				for Iter in range(MaxIter):
					print('Iteration Number:%d' %(Iter+1))
					# output the iteration number for mark !!!

					D_Fai_m=Norm2_1DiagMatrix(Fai_m)
					# calculate the reciprocal of the L_{2}-norm of each row of
					# Fai_m to obtain matrix D_Fai_m
					
					temp1_Fai_m=DrugTargetMatrix_Reduced*DrugTargetMatrix_Reduced.transpose()
					# compute \tilde{x}^m*(\tilde{x}^m)^T for singular value decomposition (SVD)
					# to get the matrix of F^m, where F^m*(F^m)^T=temp1_Fai_m
					F_m=SingularValueDecompositionWithTopSingularForReconstruction(temp1_Fai_m,SingularNumber)

					# compute the invert operation [\tilde{X}^m(\tilde{X}^m)^T+\gamma*D_Fai_m}]^{-1}
					# by woodbury operation
					Invert1=1/gamma*np.linalg.inv(D_Fai_m)
					# compute the first term of the invert operation, i.e., 1/gamma*(D_Fai_m)^{-1}
					Identity=np.mat(np.eye(SingularNumber,SingularNumber))
					# Initialize a identity matrix with the size of SingularNumber*SingularNumber
					Invert2=1/pow(gamma,2.0)*np.linalg.inv(D_Fai_m)*F_m*np.linalg.inv(Identity+
						1/gamma*F_m.transpose()*np.linalg.inv(D_Fai_m)*F_m)*F_m.transpose()*np.linalg.inv(D_Fai_m)
					# compute the second term of the invert operation in Eq. (22) of the manuscript
					InvertOperation=Invert1-Invert2
					# compute the invert operation for update matrix Fai_m

					Fai_m=DrugTargetMatrix*DrugTargetMatrix_Reduced.transpose()*InvertOperation
					# update matrix Fai_m by X^m*(\tilde{X}^m)^T*[\tilde{X}^m(\tilde{X}^m)^T+\gamma*D_Fai_m}]^{-1}

					Invert3=np.linalg.inv(temp1_Fai_m+gamma*np.linalg.inv(D_Fai_m))
					Fai_m=DrugTargetMatrix*DrugTargetMatrix_Reduced.transpose()*Invert3

					# termination condition1 for the iteration: 
					Delta_Fai_m=Fai_m-Fai_m_last
					Delta_Fai_m=np.linalg.norm(Delta_Fai_m, ord=np.inf)
					# compute the difference of Fai_m between two adjacent iterations with infinite norm 
					# i.e.,the entry with the maximum absolute value in a matrix 

					if Delta_Fai_m<=threshold:
						break

					# termination condition 2: the absolute objective function difference 
					# between two iteration is less than Delta_threshold=0.00001
					Delta=np.linalg.norm(DrugTargetMatrix-Fai_m*DrugTargetMatrix_Reduced)
					Delta=Delta+gamma*L_2_1_normMatrix(Fai_m.transpose())
					
					# compute the objective function in this iteration
					Delta_last=np.linalg.norm(DrugTargetMatrix-Fai_m_last*DrugTargetMatrix_Reduced)
					Delta_last=Delta_last+gamma*L_2_1_normMatrix(Fai_m_last.transpose())
					# compute the objective function in the last iteration

					# print(Delta,Delta_last)
					Adjacent_Loss=abs(Delta-Delta_last)/Delta
					# compute the objective function loss between two adjacent iterations 
					print('Absolute Loss=%.10f' %(Adjacent_Loss))
					if Adjacent_Loss>=Delta_threshold:  # the loss is higher than Delta_threshold=0.00001
						Fai_m_last=Fai_m  # record the current Fai_m
					elif Adjacent_Loss<Delta_threshold: # the loss is less then Delta_threshold 
						break # break the Loops

				DrugTargetMatrix_Reconstructed=Fai_m*DrugTargetMatrix_Reduced
				# use the reduced Target matrix of drugs, i.e., \tilde{X}^m, m=2
				# to reconstruct the original Target space of drugs.
				# in other words, all Target representations of drugs are represented
				# by the representative drugs with their discriminative Target

				np.save('Reconstructed'+AttributeName+' PercentSelectDrug='+str(PercentageSelectedDrug)+
					' PerSelectFeature='+str(PercentageSelectedFeature)+
					' gamma='+str(gamma), DrugTargetMatrix_Reconstructed)
				# save matrix DrugTargetMatrix_Reconstructed, this file 
				# is coded by numpy that can be read by command np.load but open with messy code
				np.savetxt('Reconstructed'+AttributeName+' PercentSelectDrug='+str(PercentageSelectedDrug)+
					' PerSelectFeature='+str(PercentageSelectedFeature)+
					' gamma='+str(gamma)+'.txt',DrugTargetMatrix_Reconstructed)
				# to directly show matrix DrugTargetMatrix_Reconstructed, we use 
				# np.savetxt to output the matrix DrugTargetMatrix_Reconstructed. 
				# This file can be opened with showing the value of each entry in DrugTargetMatrix_Reconstructed

if __name__ == '__main__':

	DrugTargetMatrixAddress='DrugTargetMatrix.txt'
	# get the file name of DrugTargetMatrix

	DrugTargetMatrix=LoadDrugTargetMatrix(DrugTargetMatrixAddress)
	# call function LoadDrugTargetMatrix to get the Target matrix of drugs

	alpha_m=[0.0001,0.001,0.01,0.05,0.1,0.5,1,5,10,100,500,1000,5000,10000]
	# alpha_m controls l_{2,1} norm of matrix Y^m, i.e., ||Y^m||_{2,1}
	# W^m = Y^m
	beta_m=[0.0001,0.001,0.01,0.05,0.1,0.5,1,5,10,100,500,1000,5000,10000]
	# alpha_m controls l_{2,1} norm of matrix Z^m, i.e., ||Z^m||_{2,1}
	# (W^m)^T = Z^m
	lambda_m=[0.0001,0.001,0.01,0.05,0.1,0.5,1,5,10,100,500,1000,5000,10000]
	# lambda_m controls the Graph Manifold Regularization 
	# tr[(X^m*W^m*X^m)^T*L^m*(X^m*W^m*X^m)]


	# Notice!!! the above three parameters controls the 
	# Representative Drugs and Discriminative Target selection shown in 
	# SelectRepresentativeDrugDiscriminativeTarget.py
	# Particularly, for Target, MADRL outputs the best results 
	# when alpha=10, beta=10, and lambda=1000. Thus, we output matrix W^m (m=2) in case of 
	# alpha=10, beta=10, and lambda=1000, and the output file is 
	# Target_W^m alpha=10, beta=10, and lambda=1000.txt. 
	# And in the following, we set alpha=10, beta=10, and lambda=1000 to get matrix W^m
	# The detailed parameter discussion for alpha, beta, and lambda can be conducted in 
	# SelectRepresentativeDrugDiscriminativeTarget.py
	# The above three parameter ranges are used to discuss their effects 
	# on the reconstruction of Target matrix of drugs 
	alpha_m=[10]
	beta_m=[10]
	lambda_m=[1000]
	# traverse the parameter set 
	for alpha in alpha_m:
		for beta in beta_m:
			for lambdaa in lambda_m:
				# for each parameter combination, get its corresponding matrix W^m,
				# the derived matrix is provided by SelectRepresentativeDrugDiscriminativeTarget.py
				# with alpha=10, beta=10, and lambda=1000
				# the W^m matrix for Target is denoted as Target_W_m, m=2
				Target_W_m=LoadW_mMatrixDerivedByDrugAndTargetSelection(
					'Target',alpha,beta,lambdaa)

				# use Target_W_m matrix to reconstruct the original 
				# Target matrix of drugs DrugTargetMatrix
				TargetMatrixReconstruction(DrugTargetMatrix,
					Target_W_m,'Target')