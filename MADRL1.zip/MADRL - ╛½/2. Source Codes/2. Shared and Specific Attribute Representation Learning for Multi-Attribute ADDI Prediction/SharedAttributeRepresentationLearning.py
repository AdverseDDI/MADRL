from matplotlib import pyplot  
import scipy as sp  
import numpy as np  
import pandas as pd
from matplotlib import pylab  
from sklearn.datasets import load_files   
from sklearn.feature_extraction.text import  CountVectorizer  
from sklearn.feature_extraction.text import  TfidfVectorizer  
from sklearn.naive_bayes import MultinomialNB  
from sklearn.metrics import precision_recall_curve, roc_curve, auc  
from sklearn.metrics import classification_report  
from sklearn.linear_model import LogisticRegression  
import time 
from scipy.linalg.misc import norm
from numpy import *
import os
from sklearn.metrics import roc_auc_score, roc_curve, auc 
from sklearn import metrics
import torch
from torch.autograd import Variable
from torch import nn, optim
from torch.utils.data import DataLoader
from torchvision.utils import save_image
np.set_printoptions(threshold=np.inf) 
torch.set_printoptions(threshold=np.inf) 

# A Generative Adversarial Network (GAN) framework for eight attributes, 
# Molecular Structure, Target, Enzyme, Pathway, Side Effect, Phenotype, Gene, Disease,so as to  
# conduct shared attribute representation learning of each adverse drug pair. Since each attribute 
# needs a generator to provide its shared attribute representation and a discriminator is designed
# for each pair of attribute to discriminate their generated shared attribute representations. 
# Thus, GAN framework totally consists of eight generators for each attributes 
# and 8*7/2=28 discriminators for all pairs of attributes. In particular, a four-layer full connection 
# network is  employed in GAN framework for generators and discriminators, in which the nodes of four 
# hidden layers for shared attribute representation learning is {256, 128, 128, 64}. Meanwhile, 
# due to that the dimensionalities for different attribute are different, each attribute  own its unique 
# generators. Since the dimensionality of the generated shared attribute representations for different 
# attributes are the same (i.e., 64), we set all discriminators share common parameters and thus, the
# number of parameters in the framework can be reduced and time efficiency
# in the training procedure will be enhanced. Besides, we use concatenation operation to fuse 
# the attribute representation of two drugs into the attribute representation of drug pairs.
# therefore, the input dimensionalities for the generators in terms of eight attribute are 
# 2*dimension(attribute). For example, the input dimensionality for generator in terms of Molecular 
# Structure is dimension of Molecular Structure*2
# We have tried Softsign, ReLU, Sigmoid, and Tanh,  and find that ReLU leads to considerable results
# the dropout rate is set to be 0.5

# the following class is the generators for shared attribute representation learning
# for Molecular Structure, Target, Enzyme, Pathway, Side Effect, Phenotype, Gene, Disease
# the a four-layer full connection network is employed with the nodes of four hidden layers being 
# {256, 128, 128, 64}. Thus, the dimensionality of the final shared attribute representations 
# of eight attributes are 64
class SharedAttributeRepresentationLearningGenerators(nn.Module):
	# MolecularStructureDimension_2 is the double dimensionality of Molecular Structure
	# TargetDimension_2 is the double dimensionality of Target
	# EnzymeDimension_2 is the double dimensionality of Enzyme
	# PathwayDimension_2 is the double dimensionality of Pathway
	# SideEffectDimension_2 is the double dimensionality of SideEffect
	# PhenotypeDimension_2 is the double dimensionality of Phenotype
	# GeneDimension_2 is the double dimensionality of Gene
	# DiseaseDimension_2 is the double dimensionality of Disease
	def __init__(self, MolecularStructureDimension_2, TargetDimension_2, EnzymeDimension_2,
		PathwayDimension_2, SideEffectDimension_2,PhenotypeDimension_2, GeneDimension_2, 
		DiseaseDimension_2):
		super(SharedAttributeRepresentationLearningGenerators, self).__init__()
		# The generator for Molecular Structure representation of adverse drug pair
		self.MolecularStructureGenerator=nn.Sequential(
			nn.Linear(MolecularStructureDimension_2,256),nn.Dropout(0.5), 
    		nn.ReLU(),
    		nn.Linear(256,128),nn.Dropout(0.5), 
    		nn.ReLU(),
    		nn.Linear(128,128),nn.Dropout(0.5), 
    		nn.ReLU(),
    		nn.Linear(128,64),
			)
		# The generator for Target representation of adverse drug pair
		self.TargetGenerator=nn.Sequential(
			nn.Linear(TargetDimension_2,256),nn.Dropout(0.5), 
    		nn.ReLU(),
    		nn.Linear(256,128),nn.Dropout(0.5), 
    		nn.ReLU(),
    		nn.Linear(128,128),nn.Dropout(0.5), 
    		nn.ReLU(),
    		nn.Linear(128,64),
			)
		# The generator for Enzyme representation of adverse drug pair
		self.EnzymesGenerator=nn.Sequential(
			nn.Linear(EnzymeDimension_2,256),nn.Dropout(0.5), 
    		nn.ReLU(),
    		nn.Linear(256,128),nn.Dropout(0.5), 
    		nn.ReLU(),
    		nn.Linear(128,128),nn.Dropout(0.5), 
    		nn.ReLU(),
    		nn.Linear(128,64),
			)
		# The generator for Pathway representation of adverse drug pair
		self.PathwayGenerator=nn.Sequential(
			nn.Linear(PathwayDimension_2,256),nn.Dropout(0.5), 
    		nn.ReLU(),
    		nn.Linear(256,128),nn.Dropout(0.5), 
    		nn.ReLU(),
    		nn.Linear(128,128),nn.Dropout(0.5), 
    		nn.ReLU(),
    		nn.Linear(128,64),
			)
		# The generator for SideEffect representation of adverse drug pair
		self.SideEffectGenerator=nn.Sequential(
			nn.Linear(SideEffectDimension_2,256),nn.Dropout(0.5), 
    		nn.ReLU(),
    		nn.Linear(256,128),nn.Dropout(0.5), 
    		nn.ReLU(),
    		nn.Linear(128,128),nn.Dropout(0.5), 
    		nn.ReLU(),
    		nn.Linear(128,64),
			)
		# The generator for Phenotype representation of adverse drug pair
		self.PhenotypeGenerator=nn.Sequential(
			nn.Linear(PhenotypeDimension_2,256),nn.Dropout(0.5), 
    		nn.ReLU(),
    		nn.Linear(256,128),nn.Dropout(0.5), 
    		nn.ReLU(),
    		nn.Linear(128,128),nn.Dropout(0.5), 
    		nn.ReLU(),
    		nn.Linear(128,64),
			)
		# The generator for Gene representation of adverse drug pair
		self.GeneGenerator=nn.Sequential(
			nn.Linear(GeneDimension_2,256),nn.Dropout(0.5), 
    		nn.ReLU(),
    		nn.Linear(256,128),nn.Dropout(0.5), 
    		nn.ReLU(),
    		nn.Linear(128,128),nn.Dropout(0.5), 
    		nn.ReLU(),
    		nn.Linear(128,64),
			)
		# The generator for Disease representation of adverse drug pair
		self.DiseaseGenerator=nn.Sequential(
			nn.Linear(DiseaseDimension_2,256),nn.Dropout(0.5), 
    		nn.ReLU(),
    		nn.Linear(256,128),nn.Dropout(0.5), 
    		nn.ReLU(),
    		nn.Linear(128,128),nn.Dropout(0.5), 
    		nn.ReLU(),
    		nn.Linear(128,64),
			)

	# forward function of the eight generators for Molecular Structure, Target, Enzyme, 
	# Pathway, Side Effect, Phenotype, Gene, and Disease. Particularly, the input of the forward function 
	# is the attribute representations of adverse drug pair in terms of eight attributes
	# The output of the forward function is the shared attribute representation of adverse drug 
	# pair in terms of eight attributes. 
	# MolecularStructureVectorPair is the Molecular Structure representation of an adverse drug pair
	# TargetVectorPair is the Target representation of an adverse drug pair
	# EnzymeVectorPair is the Enzyme representation of an adverse drug pair
	# PathwayVectorPair is the Pathway representation of an adverse drug pair
	# SideEffectVectorPair is the SideEffect representation of an adverse drug pair
	# PhenotypeVectorPair is the Phenotype representation of an adverse drug pair
	# GeneVectorPair is the Gene representation of an adverse drug pair
	# DiseaseVectorPair is the Disease representation of an adverse drug pair
	def forward(self, MolecularStructureVectorPair,TargetVectorPair, EnzymeVectorPair,PathwayVectorPair, 
		SideEffectVectorPair, PhenotypeVectorPair, GeneVectorPair, DiseaseVectorPair):
		SharedMolecularStructureVectorPair=self.MolecularStructureGenerator(MolecularStructureVectorPair)
		SharedTargetVectorPair=self.TargetGenerator(TargetVectorPair)
		SharedEnzymeVectorPair=self.EnzymesGenerator(EnzymeVectorPair)
		SharedPathwayVectorPair=self.PathwayGenerator(PathwayVectorPair)
		SharedSideEffectVectorPair=self.SideEffectGenerator(SideEffectVectorPair)
		SharedPhenotypeVectorPair=self.PhenotypeGenerator(PhenotypeVectorPair)
		SharedGeneVectorPair=self.GeneGenerator(GeneVectorPair)
		SharedDiseaseVectorPair=self.DiseaseGenerator(DiseaseVectorPair)
	# SharedMolecularStructureVectorPair is the shared Molecular Structure representation of an adverse drug pair
	# SharedTargetVectorPair is the shared Target representation of an adverse drug pair
	# SharedEnzymeVectorPair is the shared Enzyme representation of an adverse drug pair
	# SharedPathwayVectorPair is the shared Pathway representation of an adverse drug pair
	# SharedSideEffectVectorPair is the shared SideEffect representation of an adverse drug pair
	# SharedPhenotypeVectorPair is the shared Phenotype representation of an adverse drug pair
	# SharedGeneVectorPair is the shared Gene representation of an adverse drug pair
	# SharedDiseaseVectorPair is the shared Disease representation of an adverse drug pair
	# These eight input representation is in accordant with H_{ij}^{m}, m=1, ... , M in the paper 
	# where i,j denote the drug indexes of an adverse drug pair 
		return SharedMolecularStructureVectorPair,SharedTargetVectorPair,SharedEnzymeVectorPair,\
		SharedPathwayVectorPair,SharedSideEffectVectorPair,SharedPhenotypeVectorPair,SharedGeneVectorPair,\
		SharedDiseaseVectorPair

# this class is the discriminator for Shared Attribute Representation Learning, which aims at discriminating 
# the generated shared attribute representations of each pair of attributes for minimizing the consensus score 
# to exploit their consistent contributions in ADDI modeling. Due to that the dimensionality of the shared
# attribute representation for different attribute is 64, we set all discriminators that share the same 
# parameters to reduce the number of parameters in the framework, i.e., only one discriminator is used  
# to discriminate the shared attribute representations of each pair of attributes. Here, we introduce a
# weight tensor AttributeInteractionTensor to discriminate the shared attribute representations of all pairs of attributes
# the size of AttributeInteractionTensor is consistent with the dimensionality of the shared attribute representation
# of each attribute, i.e., 64*64. 
class SharedAttributeRepresentationLearningDiscriminator(nn.Module):
	def __init__(self):
		super(SharedAttributeRepresentationLearningDiscriminator, self).__init__()

		# introduced weight Tensor AttributeInteractionTensor (64*64) to discriminate the 
		# shared attribute representations of all pairs of attributes
		self.AttributeInteractionTensor=torch.nn.Parameter(torch.randn(64,64))

	# the forward function aims to use weight tensor AttributeInteractionTensor to discriminate the shared attribute 
	# representation of each pair of attributes for computing their consensus scores by the discriminator. In 
	# particular, the generators aim to maximize the consensus scores while discriminator tries to 
	# minimize the consensus scores, where consensus score P^{mn}_{ij}=D_{a}^{mn}(G_{a}^m(H^m_{ij}),G_{a}^n(H^n_{ij})),
	# m, n=1, ... ,M. 
	def forward(self, SharedMolecularStructureVectorPair, SharedTargetVectorPair, SharedEnzymeVectorPair,
		SharedPathwayVectorPair, SharedSideEffectVectorPair, SharedPhenotypeVectorPair, SharedGeneVectorPair,
		SharedDiseaseVectorPair):
	# SharedMolecularStructureVectorPair, SharedTargetVectorPair, SharedEnzymeVectorPair, SharedPathwayVectorPair
	# SharedSideEffectVectorPair, SharedPhenotypeVectorPair, SharedGeneVectorPair, SharedDiseaseVectorPair are 
	# the derived shared attribute representations of an adverse drug pair in terms of Molecular Structure,
	# Target, Enzyme, Pathway, Side Effect, Phenotype, Gene, and Disease. 
		SharedAttributeVectorPair=[]
		# SharedAttributeVectorPair is a list to record the shared attribute representations of eight attributes
		# for the convenience of the following discriminating the shared attribute representation of each pair 
		# of attributes for minimizing their consensus scores
		SharedAttributeVectorPair.append(SharedMolecularStructureVectorPair.view(1,-1))
		# append SharedMolecularStructureVectorPair into SharedAttributeVectorPair. 
		# SharedMolecularStructureVectorPair needs to be flattened into a tensor with one row.
		SharedAttributeVectorPair.append(SharedTargetVectorPair.view(1,-1))
		# append SharedTargetVectorPair into SharedAttributeVectorPair. 
		# SharedTargetVectorPair needs to be flattened into a tensor with one row.
		SharedAttributeVectorPair.append(SharedEnzymeVectorPair.view(1,-1))
		# append SharedEnzymeVectorPair into SharedAttributeVectorPair. 
		# SharedEnzymeVectorPair needs to be flattened into a tensor with one row.
		SharedAttributeVectorPair.append(SharedPathwayVectorPair.view(1,-1))
		# append SharedPathwayVectorPair into SharedAttributeVectorPair. 
		# SharedPathwayVectorPair needs to be flattened into a tensor with one row.
		SharedAttributeVectorPair.append(SharedSideEffectVectorPair.view(1,-1))
		# append SharedSideEffectVectorPair into SharedAttributeVectorPair. 
		# SharedSideEffectVectorPair needs to be flattened into a tensor with one row.
		SharedAttributeVectorPair.append(SharedPhenotypeVectorPair.view(1,-1))
		# append SharedPhenotypeVectorPair into SharedAttributeVectorPair. 
		# SharedPhenotypeVectorPair needs to be flattened into a tensor with one row.	
		SharedAttributeVectorPair.append(SharedGeneVectorPair.view(1,-1))
		# append SharedGeneVectorPair into SharedAttributeVectorPair. 
		# SharedGeneVectorPair needs to be flattened into a tensor with one row.			
		SharedAttributeVectorPair.append(SharedDiseaseVectorPair.view(1,-1))
		# append SharedDiseaseVectorPair into SharedAttributeVectorPair. 
		# SharedDiseaseVectorPair needs to be flattened into a tensor with one row.			
		AttributeNum=len(SharedAttributeVectorPair)
		# get the number of attributes from SharedAttributeVectorPair
		ConsensusScore=torch.zeros(1,1, dtype=torch.float)
		# Initialize Float ConsensusScore=0. Actually, ConsensusScore is defined as a tensor with 
		# the size of 1*1
		for i in range(AttributeNum):
			for j in range(AttributeNum):
				if i==j:
			# i=j indicates that the two attributes to be considered as attribute pair is the same
					continue
				else:
					TempValue=SharedAttributeVectorPair[i].mm(self.AttributeInteractionTensor).mm(
						torch.transpose(SharedAttributeVectorPair[j],0,1))
			# calculate the consensus score of the attribute representation of an adverse drug pair w.r.t.
			# the i-th attribute and the j-th attribute. mm is the multiply operation between two Tensors
			# torch.transpose transforms a tensor between 0-th dimension and 1-th dimension.
					ConsensusScore=ConsensusScore+TempValue
					# sum up the ConsensusScore between the i-th attribute and the j-th attribute
					# to minimize ConsensusScore to capture the consistent information of each attribute for 
					# ADDI modeling
		return ConsensusScore


# This function is to calculate consensus score based on the shared attribute attribute representations of 
# eight attributes. The above forward function in class SharedAttributeRepresentationLearningDiscriminator
# aims to minimize the consensus score and the following function seeks a opposite objective function for 
# maximizing the consensus score.  
def GeneratorConsensusScore(SharedMolecularStructureVectorPair, SharedTargetVectorPair, SharedEnzymeVectorPair,
		SharedPathwayVectorPair, SharedSideEffectVectorPair, SharedPhenotypeVectorPair, SharedGeneVectorPair,
		SharedDiseaseVectorPair,AttributeInteractionTensor):
		SharedAttributeVectorPair=[]
		# SharedAttributeVectorPair is a list to record the shared attribute representations of eight attributes
		# for the convenience of the following maximizing the consensus score of the 
		# shared attribute representation of each attribute pair 
		SharedAttributeVectorPair.append(SharedMolecularStructureVectorPair.view(1,-1))
		# append SharedMolecularStructureVectorPair into SharedAttributeVectorPair. 
		# SharedMolecularStructureVectorPair needs to be flattened into a Tensor with one row.
		SharedAttributeVectorPair.append(SharedTargetVectorPair.view(1,-1))
		# append SharedTargetVectorPair into SharedAttributeVectorPair. 
		# SharedTargetVectorPair needs to be flattened into a Tensor with one row.
		SharedAttributeVectorPair.append(SharedEnzymeVectorPair.view(1,-1))
		# append SharedEnzymeVectorPair into SharedAttributeVectorPair. 
		# SharedEnzymeVectorPair needs to be flattened into a Tensor with one row.
		SharedAttributeVectorPair.append(SharedPathwayVectorPair.view(1,-1))
		# append SharedPathwayVectorPair into SharedAttributeVectorPair. 
		# SharedPathwayVectorPair needs to be flattened into a Tensor with one row.
		SharedAttributeVectorPair.append(SharedSideEffectVectorPair.view(1,-1))
		# append SharedSideEffectVectorPair into SharedAttributeVectorPair. 
		# SharedSideEffectVectorPair needs to be flattened into a Tensor with one row.
		SharedAttributeVectorPair.append(SharedPhenotypeVectorPair.view(1,-1))
		# append SharedPhenotypeVectorPair into SharedAttributeVectorPair. 
		# SharedPhenotypeVectorPair needs to be flattened into a Tensor with one row.	
		SharedAttributeVectorPair.append(SharedGeneVectorPair.view(1,-1))
		# append SharedGeneVectorPair into SharedAttributeVectorPair. 
		# SharedGeneVectorPair needs to be flattened into a Tensor with one row.			
		SharedAttributeVectorPair.append(SharedDiseaseVectorPair.view(1,-1))
		# append SharedDiseaseVectorPair into SharedAttributeVectorPair. 
		# SharedDiseaseVectorPair needs to be flattened into a Tensor with one row.			
		AttributeNum=len(SharedAttributeVectorPair)
		# get the number of attributes from SharedAttributeVectorPair
		ConsensusScore=torch.zeros(1,1, dtype=torch.float)
		# Initialize Float ConsensusScore=0. Actually, ConsensusScore is defined as a tensor with 
		# the size of 1*1
		for i in range(AttributeNum):
			for j in range(AttributeNum):
				if i==j:
			# i=j indicates that the two attributes to be considered as attribute pair is the same
					continue
				else:
					TempValue=SharedAttributeVectorPair[i].mm(AttributeInteractionTensor).mm(
						torch.transpose(SharedAttributeVectorPair[j],0,1))
			# calculate the consensus score of the attribute representation of an adverse drug pair w.r.t.
			# the i-th attribute and the j-th attribute. mm is the multiply operation between two tensor
			# torch.transpose transforms a tensor between 0-th dimension and 1-th dimension.
					ConsensusScore=ConsensusScore+TempValue
					# sum up the ConsensusScore between the i-th attribute and the j-th attribute
		ConsensusScore=ConsensusScore*(-1)
		# NOTICE!!!!!!!, ConsensusScore*(-1) aims to maximize the consensus score for all pairs of attributes
		# thus, ConsensusScore*(-1) for minimizing the value of -ConsensusScore to maximize ConsensusScore
		return ConsensusScore