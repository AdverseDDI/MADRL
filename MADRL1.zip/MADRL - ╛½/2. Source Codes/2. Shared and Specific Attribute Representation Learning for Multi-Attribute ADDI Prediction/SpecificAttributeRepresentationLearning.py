from matplotlib import pyplot  
import scipy as sp  
import numpy as np  
import pandas as pd
from matplotlib import pylab  
from sklearn.datasets import load_files   
from sklearn.feature_extraction.text import  CountVectorizer  
from sklearn.feature_extraction.text import  TfidfVectorizer  
from sklearn.naive_bayes import MultinomialNB  
from sklearn.metrics import precision_recall_curve, roc_curve, auc  
from sklearn.metrics import classification_report  
from sklearn.linear_model import LogisticRegression  
import time 
from scipy.linalg.misc import norm
from numpy import *
import os
from sklearn.metrics import roc_auc_score, roc_curve, auc 
from sklearn import metrics
import torch
from torch.autograd import Variable
from torch import nn, optim
from torch.utils.data import DataLoader
from torchvision.utils import save_image
np.set_printoptions(threshold=np.inf) 
torch.set_printoptions(threshold=np.inf)

# A Generative Adversarial Network (GAN) framework for eight attributes, i.e.,
# Molecular Structure, Target, Enzyme, Pathway, Side Effect, Phenotype, Gene, and Disease, so as to  
# conduct specific attribute representation learning of each adverse drug pair. Since each attribute 
# needs a generator to provide its specific attribute representation and a discriminator is designed
# for each pair of attribute to discriminate their generated specific attribute representations. 
# Similar to shared attribute representation learning, GAN framework also consists of eight generators 
# for each attributes and 8*7/2=28 discriminators for all pairs of attributes. A four-layer full 
# connection network is employed in GAN framework for generators and discriminators, in which the nodes 
# of four hidden layers for specific attribute representation learning is {128, 64, 64, 32}. 
# Each attribute own its unique generators. Since the dimensionality of the generated specific 
# attribute representations for different attributes are the same (i.e., 32), we set all discriminators 
# share common parameters and thus, the number of parameters in the framework can be reduced 
# The input dimensionalities for the generators in terms of eight attribute are 
# 2*dimension(attribute). For example, the input dimensionality for generator in terms of Molecular 
# Structure is dimension of Molecular Structure*2.
# We have tried Softsign, ReLU, Sigmoid, and Tanh,  and find that ReLU leads to considerable results 
# the dropout rate is set to be 0.5

# the following class is the generators for specific attribute representation learning
# for Molecular Structure, Target, Enzyme, Pathway, Side Effect, Phenotype, Gene, Disease
# the a four-layer full connection network is employed with the nodes of four hidden layers being 
# {128, 64, 64, 32}. Thus, the dimensionality of the final specific attribute representations 
# of eight attributes are 32
class SpecificAttributeRepresentationLearningGenerators(nn.Module):
	# MolecularStructureDimension_2 is the double dimensionality of Molecular Structure
	# TargetDimension_2 is the double dimensionality of Target
	# EnzymeDimension_2 is the double dimensionality of Enzyme
	# PathwayDimension_2 is the double dimensionality of Pathway
	# SideEffectDimension_2 is the double dimensionality of SideEffect
	# PhenotypeDimension_2 is the double dimensionality of Phenotype
	# GeneDimension_2 is the double dimensionality of Gene
	# DiseaseDimension_2 is the double dimensionality of Disease
	def __init__(self, MolecularStructureDimension_2, TargetDimension_2, EnzymeDimension_2,
		PathwayDimension_2, SideEffectDimension_2,PhenotypeDimension_2, GeneDimension_2, 
		DiseaseDimension_2):
		super(SpecificAttributeRepresentationLearningGenerators, self).__init__()
		# The generator for Molecular Structure representation of adverse drug pair
		self.MolecularStructureGenerator=nn.Sequential(
			nn.Linear(MolecularStructureDimension_2,128),nn.Dropout(0.5), 
    		nn.ReLU(),
    		nn.Linear(128,64),nn.Dropout(0.5), 
    		nn.ReLU(),
    		nn.Linear(64,64),nn.Dropout(0.5), 
    		nn.ReLU(),
    		nn.Linear(64,32),
			)
		# The generator for Target representation of adverse drug pair
		self.TargetGenerator=nn.Sequential(
			nn.Linear(TargetDimension_2,128),nn.Dropout(0.5),         
    		nn.ReLU(),
    		nn.Linear(128,64),nn.Dropout(0.5), 
    		nn.ReLU(),
    		nn.Linear(64,64),nn.Dropout(0.5), 
    		nn.ReLU(),
    		nn.Linear(64,32),
			)
		# The generator for Enzyme representation of adverse drug pair
		self.EnzymesGenerator=nn.Sequential(
			nn.Linear(EnzymeDimension_2,128),nn.Dropout(0.5),         
    		nn.ReLU(),
    		nn.Linear(128,64),nn.Dropout(0.5), 
    		nn.ReLU(),
    		nn.Linear(64,64),nn.Dropout(0.5), 
    		nn.ReLU(),
    		nn.Linear(64,32),
			)
		# The generator for Pathway representation of adverse drug pair
		self.PathwayGenerator=nn.Sequential(
			nn.Linear(PathwayDimension_2,128),nn.Dropout(0.5),         
    		nn.ReLU(),
    		nn.Linear(128,64),nn.Dropout(0.5), 
    		nn.ReLU(),
    		nn.Linear(64,64),nn.Dropout(0.5), 
    		nn.ReLU(),
    		nn.Linear(64,32),
			)
		# The generator for SideEffect representation of adverse drug pair
		self.SideEffectGenerator=nn.Sequential(
			nn.Linear(SideEffectDimension_2,128),nn.Dropout(0.5),         
    		nn.ReLU(),
    		nn.Linear(128,64),nn.Dropout(0.5), 
    		nn.ReLU(),
    		nn.Linear(64,64),nn.Dropout(0.5), 
    		nn.ReLU(),
    		nn.Linear(64,32),
			)
		# The generator for Phenotype representation of adverse drug pair
		self.PhenotypeGenerator=nn.Sequential(
			nn.Linear(PhenotypeDimension_2,128),nn.Dropout(0.5),         
    		nn.ReLU(),
    		nn.Linear(128,64),nn.Dropout(0.5), 
    		nn.ReLU(),
    		nn.Linear(64,64),nn.Dropout(0.5), 
    		nn.ReLU(),
    		nn.Linear(64,32),
			)
		# The generator for Gene representation of adverse drug pair
		self.GeneGenerator=nn.Sequential(
			nn.Linear(GeneDimension_2,128),nn.Dropout(0.5),         
    		nn.ReLU(),
    		nn.Linear(128,64),nn.Dropout(0.5), 
    		nn.ReLU(),
    		nn.Linear(64,64),nn.Dropout(0.5), 
    		nn.ReLU(),
    		nn.Linear(64,32),
			)
		# The generator for Disease representation of adverse drug pair
		self.DiseaseGenerator=nn.Sequential(
			nn.Linear(DiseaseDimension_2,128),nn.Dropout(0.5),         
    		nn.ReLU(),
    		nn.Linear(128,64),nn.Dropout(0.5), 
    		nn.ReLU(),
    		nn.Linear(64,64),nn.Dropout(0.5), 
    		nn.ReLU(),
    		nn.Linear(64,32),
			)

	# forward function of the eight generators for Molecular Structure, Target, Enzyme, 
	# Pathway, Side Effect, Phenotype, Gene, and Disease. Particularly, the input of the forward function 
	# is the attribute representations of adverse drug pair in terms of eight attributes
	# MolecularStructureVectorPair is the Molecular Structure representation of an adverse drug pair
	# TargetVectorPair is the Target representation of an adverse drug pair
	# EnzymeVectorPair is the Enzyme representation of an adverse drug pair
	# PathwayVectorPair is the Pathway representation of an adverse drug pair
	# SideEffectVectorPair is the SideEffect representation of an adverse drug pair
	# PhenotypeVectorPair is the Phenotype representation of an adverse drug pair
	# GeneVectorPair is the Gene representation of an adverse drug pair
	# DiseaseVectorPair is the Disease representation of an adverse drug pair
	def forward(self, MolecularStructureVectorPair,TargetVectorPair, EnzymeVectorPair,PathwayVectorPair, 
		SideEffectVectorPair, PhenotypeVectorPair, GeneVectorPair, DiseaseVectorPair):
		SpecificMolecularStructureVectorPair=self.MolecularStructureGenerator(MolecularStructureVectorPair)
		SpecificTargetVectorPair=self.TargetGenerator(TargetVectorPair)
		SpecificEnzymeVectorPair=self.EnzymesGenerator(EnzymeVectorPair)
		SpecificPathwayVectorPair=self.PathwayGenerator(PathwayVectorPair)
		SpecificSideEffectVectorPair=self.SideEffectGenerator(SideEffectVectorPair)
		SpecificPhenotypeVectorPair=self.PhenotypeGenerator(PhenotypeVectorPair)
		SpecificGeneVectorPair=self.GeneGenerator(GeneVectorPair)
		SpecificDiseaseVectorPair=self.DiseaseGenerator(DiseaseVectorPair)
	# SpecificMolecularStructureVectorPair is the Specific Molecular Structure representation of an adverse drug pair
	# SpecificTargetVectorPair is the Specific Target representation of an adverse drug pair
	# SpecificEnzymeVectorPair is the Specific Enzyme representation of an adverse drug pair
	# SpecificPathwayVectorPair is the Specific Pathway representation of an adverse drug pair
	# SpecificSideEffectVectorPair is the Specific SideEffect representation of an adverse drug pair
	# SpecificPhenotypeVectorPair is the Specific Phenotype representation of an adverse drug pair
	# SpecificGeneVectorPair is the Specific Gene representation of an adverse drug pair
	# SpecificDiseaseVectorPair is the Specific Disease representation of an adverse drug pair
	# These eight input representation is in accordant with H_{ij}^{m}, m=1, ... , M in the paper 
	# where i,j denote the drug indexes of an adverse drug pair 
		return SpecificMolecularStructureVectorPair,SpecificTargetVectorPair,SpecificEnzymeVectorPair,\
		SpecificPathwayVectorPair,SpecificSideEffectVectorPair,SpecificPhenotypeVectorPair,SpecificGeneVectorPair,\
		SpecificDiseaseVectorPair

# this class is the discriminator for Specific Attribute Representation Learning. Due to that the dimensionality 
# of the specific attribute representation for different attribute is 32, we set all discriminators that share the same 
# parameters to reduce the number of parameters in the framework, i.e., only one discriminator is used to discriminate 
# the specific attribute representations of each pair of attributes. Here, we introduce a weight tensor 
# AttributeInteractionTensor to discriminate the specific attribute representations of all pairs of attributes
# the size of AttributeInteractionTensor is consistent with the dimensionality of the specific attribute representation
# of each attribute, i.e., 32*32. 
class SpecificAttributeRepresentationLearningDiscriminator(nn.Module):
	def __init__(self):
		super(SpecificAttributeRepresentationLearningDiscriminator, self).__init__()

		# introduced weight tensor AttributeInteractionTensor (64*64) to discriminate the 
		# specific attribute representations of all pairs of attributes
		self.AttributeInteractionTensor=torch.nn.Parameter(torch.randn(32,32))

	# the forward function aims to use weight tensor AttributeInteractionTensor to discriminate the specific attribute 
	# representation of each pair of attributes for computing their complementary scores by the discriminator. Contrary to 
	# shared attribute representation learning, the generators aim to minimize the complementary scores 
	# while discriminator tries to maximize the complementary scores, where complementary score 
	# Q^{mn}_{ij}=D_{b}^{mn}(G_{b}^m(H^m_{ij}),G_{b}^n(H^n_{ij})), m, n=1, ... ,M. 
	def forward(self, SpecificMolecularStructureVectorPair, SpecificTargetVectorPair, SpecificEnzymeVectorPair,
		SpecificPathwayVectorPair, SpecificSideEffectVectorPair, SpecificPhenotypeVectorPair, SpecificGeneVectorPair,
		SpecificDiseaseVectorPair):
	# SpecificMolecularStructureVectorPair, SpecificTargetVectorPair, SpecificEnzymeVectorPair, SpecificPathwayVectorPair
	# SpecificSideEffectVectorPair, SpecificPhenotypeVectorPair, SpecificGeneVectorPair, SpecificDiseaseVectorPair are 
	# the derived specific attribute representations of an adverse drug pair in terms of Molecular Structure,
	# Target, Enzyme, Pathway, Side Effect, Phenotype, Gene, and Disease. 
		SpecificAttributeVectorPair=[]
		# SpecificAttributeVectorPair is a list to record the specific attribute representations of eight attributes
		# for the convenience of the following discriminating the specific attribute representation of each pair 
		# of attributes for maximizing their complementary scores
		SpecificAttributeVectorPair.append(SpecificMolecularStructureVectorPair.view(1,-1))
		# append SpecificMolecularStructureVectorPair into SpecificAttributeVectorPair. 
		# SpecificMolecularStructureVectorPair needs to be flattened into a tensor with one row.
		SpecificAttributeVectorPair.append(SpecificTargetVectorPair.view(1,-1))
		# append SpecificTargetVectorPair into SpecificAttributeVectorPair. 
		# SpecificTargetVectorPair needs to be flattened into a tensor with one row.
		SpecificAttributeVectorPair.append(SpecificEnzymeVectorPair.view(1,-1))
		# append SpecificEnzymeVectorPair into SpecificAttributeVectorPair. 
		# SpecificEnzymeVectorPair needs to be flattened into a tensor with one row.
		SpecificAttributeVectorPair.append(SpecificPathwayVectorPair.view(1,-1))
		# append SpecificPathwayVectorPair into SpecificAttributeVectorPair. 
		# SpecificPathwayVectorPair needs to be flattened into a tensor with one row.
		SpecificAttributeVectorPair.append(SpecificSideEffectVectorPair.view(1,-1))
		# append SpecificSideEffectVectorPair into SpecificAttributeVectorPair. 
		# SpecificSideEffectVectorPair needs to be flattened into a tensor with one row.
		SpecificAttributeVectorPair.append(SpecificPhenotypeVectorPair.view(1,-1))
		# append SpecificPhenotypeVectorPair into SpecificAttributeVectorPair. 
		# SpecificPhenotypeVectorPair needs to be flattened into a tensor with one row.	
		SpecificAttributeVectorPair.append(SpecificGeneVectorPair.view(1,-1))
		# append SpecificGeneVectorPair into SpecificAttributeVectorPair. 
		# SpecificGeneVectorPair needs to be flattened into a tensor with one row.			
		SpecificAttributeVectorPair.append(SpecificDiseaseVectorPair.view(1,-1))
		# append SpecificDiseaseVectorPair into SpecificAttributeVectorPair. 
		# SpecificDiseaseVectorPair needs to be flattened into a tensor with one row.			
		AttributeNum=len(SpecificAttributeVectorPair)
		# get the number of attributes from SpecificAttributeVectorPair
		ComplementaryScore=torch.zeros(1,1, dtype=torch.float)
		# Initialize Float ComplementaryScore=0. Actually, ComplementaryScore is defined as a tensor with 
		# the size of 1*1
		for i in range(AttributeNum):
			for j in range(AttributeNum):
				if i==j:
			# i=j indicates that the two attributes to be considered as attribute pair is the same
					continue
				else:
					TempValue=SpecificAttributeVectorPair[i].mm(self.AttributeInteractionTensor).mm(
						torch.transpose(SpecificAttributeVectorPair[j],0,1))
			# calculate the complementary score of the attribute representation of an adverse drug pair w.r.t.
			# the i-th attribute and the j-th attribute. mm is the multiply operation between two Tensors
			# torch.transpose transforms a tensor between 0-th dimension and 1-th dimension.
					ComplementaryScore=ComplementaryScore+TempValue
					# sum up the complementaryScore between the i-th attribute and the j-th attribute
		ComplementaryScore=ComplementaryScore*(-1)
		# since discriminator tries to maximize complementary scores for all pairs of attributes
		# thus, ComplementaryScore*(-1) for minimizing the value of -ComplementaryScore to maximize ComplementaryScore
		return ComplementaryScore


# This function is to calculate complementary score based on the specific attribute attribute representations of 
# eight attributes. The above forward function in class SpecificAttributeRepresentationLearningDiscriminator
# aims to maximize the complementary score and the following function seeks a opposite objective function for 
# minimizing the complementary score.  
def GeneratorComplementaryScore(SpecificMolecularStructureVectorPair, SpecificTargetVectorPair, SpecificEnzymeVectorPair,
		SpecificPathwayVectorPair, SpecificSideEffectVectorPair, SpecificPhenotypeVectorPair, SpecificGeneVectorPair,
		SpecificDiseaseVectorPair,AttributeInteractionTensor):
		SpecificAttributeVectorPair=[]
		# SpecificAttributeVectorPair is a list to record the Specific attribute representations of eight attributes
		# for the convenience of the following minimizing the complementary score of the 
		# Specific attribute representation of each attribute pair 
		SpecificAttributeVectorPair.append(SpecificMolecularStructureVectorPair.view(1,-1))
		# append SpecificMolecularStructureVectorPair into SpecificAttributeVectorPair. 
		# SpecificMolecularStructureVectorPair needs to be flattened into a tensor with one row.
		SpecificAttributeVectorPair.append(SpecificTargetVectorPair.view(1,-1))
		# append SpecificTargetVectorPair into SpecificAttributeVectorPair. 
		# SpecificTargetVectorPair needs to be flattened into a tensor with one row.
		SpecificAttributeVectorPair.append(SpecificEnzymeVectorPair.view(1,-1))
		# append SpecificEnzymeVectorPair into SpecificAttributeVectorPair. 
		# SpecificEnzymeVectorPair needs to be flattened into a tensor with one row.
		SpecificAttributeVectorPair.append(SpecificPathwayVectorPair.view(1,-1))
		# append SpecificPathwayVectorPair into SpecificAttributeVectorPair. 
		# SpecificPathwayVectorPair needs to be flattened into a tensor with one row.
		SpecificAttributeVectorPair.append(SpecificSideEffectVectorPair.view(1,-1))
		# append SpecificSideEffectVectorPair into SpecificAttributeVectorPair. 
		# SpecificSideEffectVectorPair needs to be flattened into a tensor with one row.
		SpecificAttributeVectorPair.append(SpecificPhenotypeVectorPair.view(1,-1))
		# append SpecificPhenotypeVectorPair into SpecificPhenotypeVectorPair. 
		# SpecificPhenotypeVectorPair needs to be flattened into a tensor with one row.	
		SpecificAttributeVectorPair.append(SpecificGeneVectorPair.view(1,-1))
		# append SpecificGeneVectorPair into SpecificGeneVectorPair. 
		# SpecificGeneVectorPair needs to be flattened into a tensor with one row.			
		SpecificAttributeVectorPair.append(SpecificDiseaseVectorPair.view(1,-1))
		# append SpecificDiseaseVectorPair into SpecificDiseaseVectorPair. 
		# SpecificDiseaseVectorPair needs to be flattened into a tensor with one row.			
		AttributeNum=len(SpecificAttributeVectorPair)
		# get the number of attributes from SpecificAttributeVectorPair
		ComplementaryScore=torch.zeros(1,1, dtype=torch.float)
		# Initialize Float ComplementaryScore=0. Actually, ComplementaryScore is defined as a tensor with 
		# the size of 1*1
		for i in range(AttributeNum):
			for j in range(AttributeNum):
				if i==j:
			# i=j indicates that the two attributes to be considered as attribute pair is the same
					continue
				else:
					TempValue=SpecificAttributeVectorPair[i].mm(AttributeInteractionTensor).mm(
						torch.transpose(SpecificAttributeVectorPair[j],0,1))
			# calculate the complementary score of the attribute representation of an adverse drug pair w.r.t.
			# the i-th attribute and the j-th attribute. mm is the multiply operation between two tensors
			# torch.transpose transforms a tensor between 0-th dimension and 1-th dimension.
					ComplementaryScore=ComplementaryScore+TempValue
			# sum up the ComplementaryScore between the i-th attribute and the j-th attribute
			# to minimize ComplementaryScore to capture the unique information of each attribute for 
			# ADDI modeling
		return ComplementaryScore